# 项目级 PRD 规范

项目内新写或更新正式产品 PRD 时，统一使用 PRD Suite v2.0.0。套件的原始模板、契约、流程和校验器保存在 [PRD Suite v2.0.0](prd-suite-v2.0.0/使用指南.md)，随 Skill 安装包分发。正式 PRD 的结构、字段、决策依据和修订规则以套件为准。仅初始化仓库、整理普通文档或处理 Git 协作时，按当前任务交付。

## 按任务读取套件

| 场景 | 使用入口 |
| --- | --- |
| 方向尚未确定 | [prd-explore](prd-suite-v2.0.0/skills/prd-explore/SKILL.md) 产出探索记录 |
| 材料缺关键业务决策 | [grill-me](prd-suite-v2.0.0/skills/grill-me/SKILL.md) 补齐缺项 |
| 新写 PRD、已确认 PRD 变更、从原型或现有系统反推 | [prd-doc](prd-suite-v2.0.0/skills/prd-doc/SKILL.md)，按成文、正向同步或反向识别执行 |

写作时读取 [PRD 契约](prd-suite-v2.0.0/skills/prd-doc/references/prd-contract.md) 和 [质量门槛](prd-suite-v2.0.0/skills/prd-doc/references/quality-gates.md)。用原始模板生成新建 PRD 的 14 节与项目简介，或增量 PRD 的 6 节与决策摘要。共识与反向识别结果按原流程确认。用户已经明确确认且有可追溯依据的决策可以复用。业务事实、评审结论、版本和验收均按实际记录。

## 放入 Git 项目

先按套件在独立工作目录准备文档和校验所需的材料。使用 `init --dir`，目录末段与 `prd_id` 一致。输出到项目的是通过校验的 `PRD.md`。采用本 Skill 骨架时，放在 `docs/versions/<迭代版本>/<需求|新增|变更>/<slug>/PRD.md`，由需求卡的 `document` 指向这份文件。已有项目沿用其已约定的文档位置。

套件校验需要在工作目录中读取与 PRD 同级的 `项目简介.md` 或 `决策摘要.md`，以及成文时的 `拷问结论.md`。这些是校验和追溯材料，保存在工作目录。项目需要保留依据时可在 `prd-work/<迭代版本>/<范围类型>/<slug>/` 保存材料，正式正文仍以项目文档目录中的 PRD 为准。再次修改时，以当前正式 PRD 为输入，放入工作目录与材料一起同步和校验，通过后更新同一正式文件。

用现有 Git 需求 ID 登记迭代范围与变更，并在概要总览或交接中标明对应的套件需求 ID，例如 `REQ-017 → 需求-003`。一个 PRD 可以覆盖多条相关需求。套件的 `schema_version`、PRD 修订号 `version` 和 Git 迭代目录各有含义。按套件的 `bump` 升 PRD 修订版。已有项目沿用已确认的迭代与生效基线，需要重写的内容按本次范围增量转换。

## 交付前验证

以下 `<skill-dir>` 是当前 Git 项目构建 Skill 的实际目录。Python 3.8+ 可运行套件原始校验器。

```bash
tool="<skill-dir>/references/prd-suite-v2.0.0/skills/prd-doc/scripts/prd_tool.py"
python3 "$tool" init --dir "<产物目录>" --slug "<slug>" --title "<标题>" --date "<本地 ISO 日期>" --mode "<新建或增量>"
python3 "$tool" conclusion --file "<产物目录>/拷问结论.md" --gate ready --receipt
python3 "$tool" check --prd "<产物目录>/PRD.md" --gate ready --receipt
```

正式交付时，按套件复核共识、内容与状态。只交付文档且本次没有随 PRD 一起校验的套件原型时，按契约用 `prototype: null`。既有原型作为需求材料或项目原型入口时，沿用已有项目的关联方式。校验回执保留未检查项，缺少业务确认时按实际状态交付。正式 PRD 进入 Git 版本目录后按项目规则更新索引，核对需求卡链接。
