"""prd-suite v2.0.0 回归测试。

v2.0.0 是一次**减法 + 双向**的破坏性升级，每条都要有正反两侧的回归测试：

  · 图证机制整体拆除：子命令只剩 init/check/conclusion/bump，交互表回 12 字段，
    正文里出现「图证」字样不再报错（按未知内容忽略），回执 not_checked 不再提图证；
  · 契约升 2.0.0，旧号 1.0.0–1.6.0 继续可判，旧文档里多出的 动效/图证/实测 三列被忽略；
  · 原型多文件：标记闭合跨文件聚合，`prototype.<slug>.html` 必须带 data-page-id，
    PRD 声明的页面逐个被覆盖；索引页豁免「事件绑定 / 样式规则数」两项高保真检查；
  · 原型草案：`data-prd-id="draft"` 的文件跳过版本一致性与标记闭合，ready 门只给 warning；
  · bump 遍历所有原型文件，草案文件不被触碰。

用法：
    cd prd-suite && uv run python -m unittest discover -s validation -v
"""
import contextlib
import importlib.util
import io
import json
import re
import shutil
import tempfile
import unittest
import unittest.mock
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"
TOOL = SKILLS / "prd-doc/scripts/prd_tool.py"
spec = importlib.util.spec_from_file_location("prd_tool", TOOL)
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)

EXAMPLE = ROOT / "examples/feedback-board"

# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------

INT_FIELDS_V2 = (
    "关联需求", "页面/组件", "触发与前置状态", "输入与校验", "权限",
    "处理中反馈", "成功结果", "失败与恢复", "空态/无权限", "重复/并发",
    "取消/退出", "验收",
)
INT_FIELDS_V15 = (
    "关联需求", "页面/组件", "触发与前置状态", "输入与校验", "权限",
    "处理中反馈", "成功结果", "失败与恢复", "空态/无权限", "重复/并发",
    "取消/退出", "动效", "图证", "实测", "验收",
)

INTERACTION_VALUES = {
    "关联需求": "需求-001",
    "页面/组件": "页面-001 导入区",
    "触发与前置状态": "页面加载完成，已选择财务角色",
    "输入与校验": "选择 CSV 文件，校验后缀与体积",
    "权限": "仅财务角色可导入",
    "处理中反馈": "显示导入进度条",
    "成功结果": "列出解析后的流水条数",
    "失败与恢复": "提示具体错误行号并保留已选文件",
    "空态/无权限": "未选文件时导入按钮禁用",
    "重复/并发": "同一文件可重复导入，按文件名去重",
    "取消/退出": "导入过程中可点击取消",
    "动效": "无：进度条瞬时更新",
    "图证": "需求-001.png（原型实测）",
    "实测": "不适用：无实测",
    "验收": "验收-001",
}

INTRO_V2 = """# 最小样例 项目简介

> 对应 PRD：PRD.md（0.1.0）

## 背景

小微企业每月都要对一次银行流水和内部记账。现在这件事由财务手工完成：导出两个表，按日期一列一列对，遇到同名同金额的条目还要回查单据。对账本身不产生任何业务价值，却占掉每月最忙的那两天。这个项目就是为了把这两天压回十分钟。

## 痛点

第一个痛点是重复劳动。同一条流水要在两个表之间来回找，找一次两分钟，一次对账几百条。第二个痛点是错误不可见。手工核对时漏过的差异不会自己跳出来，等到月末结账才发现，补救成本翻倍。第三个痛点是交接困难。对账过程没有任何记录，换人接手要重新理解一遍全部口径。

## 大致思路

把「导入、匹配、看差异」三件事收进一个桌面页面。财务选一个 CSV 文件导入，工具解析出流水行，按日期与金额自动配对，把对不上的行单独列出来。所有解析与匹配都在本地完成，不依赖银行接口，也不上传任何数据。第一版只做这一条主路径，多人协作、审批、导出报表都不在范围内。

## 怎么解决

导入环节先校验文件后缀与体积，超过限制直接拒绝并说明原因；解析失败的行走错误清单，指出第几行第几列出问题，而不是整批失败。匹配环节按日期加金额配对，配不上的一律进差异列表，不做任何猜测性的模糊匹配。差异列表给出「仅在银行」「仅在账内」两类标签，财务只看这两组就能完成对账。导入的每个文件都会记住文件名与条数，重复导入时先比对再决定是否覆盖，避免同一份文件被算两遍。
"""

PAGE_ROW_001 = "| 页面-001 | 对账工作台 | 财务导入流水并核对差异 | 导入后停留本页，不跳转 |"
PAGE_ROW_002 = "| 页面-002 | 差异详情 | 财务查看单条差异的来源 | 返回列表 |"

PRD_TEMPLATE = """---
schema_version: "{schema}"
prd_id: "demo-min"
title: '最小样例'
version: "0.1.0"
status: "草稿"
updated_at: "2026-11-03"
prototype: {prototype}
doc_mode: "新建"
---

# 最小样例 产品需求文档（PRD）

## 一页摘要

| 项目 | 内容 |
| --- | --- |
| 一句话 | 让财务把对账从两天压到十分钟的桌面工具 |
| 问题 | 手工对两套流水，重复劳动多、漏检不可见、换人接手要重学口径 |
| 用户 | 十人以下小微企业里唯一的一名财务 |
| 方案 | 单页导入、自动匹配、差异列表，全部本地完成 |
| 成功指标 | 一次对账耗时从两小时降到十分钟 |
| 本期不做 | 多人协作、审批流、报表导出 |
| 最大风险 | 银行导出格式变化导致解析失败 |

## 1. 需求背景

> 本章结论：现状是手工对账，最痛的是漏检不可见。

财务每月导出两份表，按日期与金额人工配对，配不上的回查单据。竞品对比：

> 未提供：本期没有竞品材料，未做竞品对比。

## 2. 目标与成功指标

> 本章结论：对账耗时从两小时降到十分钟。

| 指标 | 基线 | 目标 | 观测方式 |
| --- | --- | --- | --- |
| 单次对账耗时 | 未提供：没有基线数据，本期先埋点再定 | 十分钟 | 本地计时埋点 |

## 3. 用户、角色与场景

> 本章结论：只有一个角色，桌面浏览器环境。

| 角色 | 任务 | 使用频率 | 环境/限制 |
| --- | --- | --- | --- |
| 财务 | 导入流水、核对差异 | 未提供：没有使用频率数据 | 桌面浏览器，窄屏不保证 |

## 4. 方案与范围

> 本章结论：只做桌面端单页，本地解析与匹配。

- **本期包含**：导入 CSV、自动匹配、差异列表。
- **本期不做**：多人协作与审批流。
- **阶段边界**：先做桌面端，窄屏适配留给下一版。
- **依赖**：未提供：银行导出格式尚未与财务确认。

## 5. 需求范围与用户流程

> 本章结论：全部操作发生在一个工作台页面内。

| ID | 页面/入口 | 角色与职责 | 流程/出口 |
| --- | --- | --- | --- |
{page_rows}

## 6. 功能详细说明

> 本章结论：本期只有一条导入需求。

### 用户故事

- 作为 **财务**，我想 **一次导入整月流水**，以便 **立刻看到对不上的行**。

### 需求清单

| ID | 优先级 | 要求与边界 | 来源/决策 | 验收 |
| --- | --- | --- | --- | --- |
| 需求-001 | P0 | 可导入 CSV 流水，单文件不超过 10 MB；解析失败逐行报错不整批失败 | 决策-001 | 验收-001 |

## 7. 交互与状态

> 本章结论：导入交互覆盖校验、失败恢复与取消。

### 交互-001 导入流水

{interaction_rows}

## 8. 数据、权限与业务规则

> 本章结论：流水按行存储，行内三列必填。

| ID | 字段/规则 | 类型与约束 | 来源/生命周期 |
| --- | --- | --- | --- |
| 数据-001 | 流水行 | 日期、金额、摘要三列必填 | 决策-001；导入时创建，随文件保留 |

## 9. 非功能需求

> 本章结论：十万行以内必须十秒解析完。

| ID | 约束与验证方法 | 来源/决策 | 验收 |
| --- | --- | --- | --- |
| 非功能约束-001 | 十万行以内十秒内解析完成，以本地实测耗时验证 | 决策-001 | 验收-002 |

## 10. 验收标准

> 本章结论：两条验收覆盖导入主路径与解析性能。

| ID | 关联需求 | 前提 | 操作 | 预期 | 类型 |
| --- | --- | --- | --- | --- | --- |
| 验收-001 | 需求-001 | 手上有不超过 10 MB 的 CSV 流水 | 选择文件并导入 | 列出解析条数，无报错 | 正向 |
| 验收-002 | 非功能约束-001 | 手上有十万行流水 | 导入并计时 | 十秒内完成解析 | 非功能 |

## 11. 风险、依赖与开放问题

> 本章结论：银行格式变化是主要风险。

### 风险与依赖

- **风险**：银行导出格式变化导致解析失败。影响：导入不可用。缓解：解析失败时给出具体行列号。

### 开放问题与假设

| ID | 类型 | 影响需求 | 影响级别 | 内容/理由 | 状态 | 处理方案/负责人 |
| --- | --- | --- | --- | --- | --- | --- |
| 假设-001 | 假设 | 需求-001 | 非阻塞 | 样例数据格式与线上一致 | 已采纳 | 见 决策-001 |

## 12. 非功能以外的交付项：埋点

> 本章结论：本期不做数据采集。

不适用：本期不做数据采集。

## 13. 项目规划

> 本章结论：排期未定，只锁定首版范围。

| 阶段 | 范围 | 时间 | 退出条件 |
| --- | --- | --- | --- |
| 首版 | 导入与差异列表 | 未提供：排期未定 | 导入主路径走通 |

## 14. 决策、来源与变更

> 本章结论：一个决策锁定本期范围。

### 决策

| ID | 决策 | 依据/来源 | 确认者与证据 | 影响范围 |
| --- | --- | --- | --- | --- |
| 决策-001 | 本期只做桌面端单页导入对账 | 拷问结论已定决策第 1 条 | 用户口述确认 | 全部章节 |

### 来源

| ID | 来源 | 位置与摘要 | 可信度/限制 |
| --- | --- | --- | --- |
| 来源-001 | 拷问结论 | 拷问结论.md | 用户口述，未经书面确认 |

### 版本记录

| 版本 | 日期 | 类型 | 核心修改内容 | 关联决策 |
| --- | --- | --- | --- | --- |
| 0.1.0 | 2026-11-03 | 初版 | 建立导入对账基线（需求-001、验收-001） | 决策-001 |
"""


def interaction_block(fields=INT_FIELDS_V2):
    rows = "\n".join(f"| {name} | {INTERACTION_VALUES[name]} |" for name in fields)
    return "| 字段 | 规格 |\n| --- | --- |\n" + rows


def make_min_prd(schema="2.0.0", prototype="null", fields=INT_FIELDS_V2,
                 extra_body="", pages=(PAGE_ROW_001,)):
    """14 节最小 PRD。fields 决定交互表 12 / 15 字段，pages 决定页面表行数。"""
    text = PRD_TEMPLATE.format(
        schema=schema,
        prototype=prototype,
        interaction_rows=interaction_block(fields),
        page_rows="\n".join(pages),
    )
    if extra_body:
        text = text.replace("## 8. 数据、权限与业务规则",
                            extra_body + "\n## 8. 数据、权限与业务规则")
    return text


PROTOTYPE_HEAD = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>对账工作台</title>
"""

PROTOTYPE_STYLE = """<style>
:root { --ink: #24211d; --paper: #fbf7ef; --line: #ddd; --muted: #666; }
body { margin: 0; font-family: sans-serif; color: var(--ink); background: var(--paper); }
.wrap { max-width: 960px; margin: 0 auto; padding: 24px; }
h1 { font-size: 20px; margin: 0 0 12px; }
h2 { font-size: 16px; margin: 16px 0 8px; }
.row { display: flex; gap: 12px; align-items: center; }
.card { border: 1px solid var(--line); border-radius: 8px; padding: 16px; }
.btn { padding: 8px 16px; border-radius: 6px; border: 1px solid #333; background: #fff; }
.btn:disabled { opacity: .5; }
.list { list-style: none; margin: 12px 0 0; padding: 0; }
.list li { padding: 8px 0; border-bottom: 1px solid #eee; }
.tag { display: inline-block; font-size: 12px; padding: 2px 6px; border-radius: 4px; }
.tag-a { background: #ffe6df; }
.tag-b { background: #e4f2e6; }
.empty { color: var(--muted); padding: 16px 0; }
.bar { height: 6px; background: #eee; border-radius: 3px; }
.bar > i { display: block; height: 6px; width: 0; background: #333; border-radius: 3px; }
.note { font-size: 13px; color: #555; }
.nav { display: flex; gap: 8px; margin: 12px 0; }
.nav a { color: #1e6494; }
@media (max-width: 480px) { .wrap { padding: 12px; } .row { flex-direction: column; } }
</style>
"""

PROTOTYPE_SCRIPT = """<script>
const input = document.getElementById('file');
const button = document.getElementById('import');
const msg = document.getElementById('msg');
const list = document.getElementById('list');
const empty = document.getElementById('empty');
const progress = document.getElementById('progress');
if (input && button) {
  input.addEventListener('change', () => {
    const picked = input.files && input.files[0];
    button.disabled = !picked;
    msg.textContent = picked ? '已选择：' + picked.name : '选择一个 CSV 文件开始';
  });
  button.addEventListener('click', () => {
    const picked = input.files && input.files[0];
    if (!picked) { msg.textContent = '请先选择文件'; return; }
    if (!picked.name.toLowerCase().endsWith('.csv')) { msg.textContent = '只支持 CSV'; return; }
    if (picked.size > 10 * 1024 * 1024) { msg.textContent = '文件超过 10 MB'; return; }
    progress.style.width = '100%';
    const item = document.createElement('li');
    item.textContent = picked.name + '（解析完成）';
    list.appendChild(item);
    empty.hidden = true;
    msg.textContent = '解析完成，共 1 行';
  });
}
</script>
"""

MARKERS = (' data-req-id="需求-001" data-int-id="交互-001" data-ac-id="验收-001"')


def prototype_html(page_id=None, prd_id="demo-min", version="0.1.0", script=True,
                   style_rules=True, markers=MARKERS):
    """生成一份原型 HTML。page_id 为 None 时不加 data-page-id。"""
    attrs = f' data-prd-id="{prd_id}"'
    if version is not None:
        attrs += f' data-prd-version="{version}"'
    if page_id:
        attrs += f' data-page-id="{page_id}"'
    style = PROTOTYPE_STYLE if style_rules else "<style>body { margin: 0; }</style>\n"
    body_script = PROTOTYPE_SCRIPT if script else "<script>/* 索引页无交互 */</script>\n"
    return (PROTOTYPE_HEAD + style + "</head>\n<body" + attrs + ">\n"
            '<div class="wrap"' + (markers or "") + ">\n"
            "<h1>对账工作台</h1>\n"
            '<div class="card">\n  <div class="row">\n'
            '    <input type="file" id="file">\n'
            '    <button class="btn" id="import">导入</button>\n'
            "  </div>\n"
            '  <div class="bar" aria-hidden="true"><i id="progress"></i></div>\n'
            '  <p class="note" id="msg">选择一个 CSV 文件开始</p>\n'
            "</div>\n"
            '<ul class="list" id="list"></ul>\n'
            '<p class="empty" id="empty">还没有导入任何流水</p>\n'
            "</div>\n" + body_script + "</body>\n</html>\n")


def write_project(root, prd_text=None, intro=None, conclusion=False, prototype=None,
                  extra_files=None):
    """在 root 下写出一个完整产物目录。"""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    (root / "PRD.md").write_text(prd_text if prd_text is not None else make_min_prd(),
                                encoding="utf-8")
    (root / "项目简介.md").write_text(INTRO_V2 if intro is None else intro, encoding="utf-8")
    if conclusion:
        (root / "拷问结论.md").write_text(EXAMPLE_CONCLUSION, encoding="utf-8")
    for name, html in (prototype or {}).items():
        (root / name).write_text(html, encoding="utf-8")
    for name, text in (extra_files or {}).items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    return root


EXAMPLE_CONCLUSION = (EXAMPLE / "拷问结论.md").read_text(encoding="utf-8")


class TempDirMixin:
    def setUp(self):
        self._tmp = tempfile.mkdtemp(prefix="prd-v2-")
        self.tmp = Path(self._tmp)

    def tearDown(self):
        shutil.rmtree(self._tmp, ignore_errors=True)

    def check(self, gate="ready"):
        return tool.check_prd(self.tmp / "PRD.md", gate)


# ---------------------------------------------------------------------------
# Task 2：图证机制拆除 + schema 2.0.0
# ---------------------------------------------------------------------------

class TestSchemaV2(TempDirMixin, unittest.TestCase):
    def test_constants(self):
        self.assertEqual(tool.SCHEMA_VERSION, "2.0.0")
        self.assertIn("2.0.0", tool.SCHEMA_VERSIONS)
        for old in ("1.0.0", "1.1.0", "1.2.0", "1.3.0", "1.4.0", "1.6.0"):
            self.assertIn(old, tool.SCHEMA_VERSIONS)

    def test_int_fields_is_twelve(self):
        self.assertEqual(tool.INT_FIELDS, set(INT_FIELDS_V2))
        for gone in ("动效", "图证", "实测"):
            self.assertNotIn(gone, tool.INT_FIELDS)

    def test_v2_prd_passes_ready(self):
        write_project(self.tmp)
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(result["errors"], [])
        self.assertEqual(result["schema_version"], "2.0.0")
        self.assertEqual(result["counts"]["interactions"], 1)

    def test_v2_prd_init_creates_v2_skeleton(self):
        target = self.tmp / "project"
        result = tool.init_project(str(target), "demo-min", "最小样例", "2026-11-03")
        self.assertTrue(result["ok"])
        meta, body, _ = tool.load_doc(target / "PRD.md")
        self.assertEqual(meta["schema_version"], "2.0.0")

    def test_unknown_schema_rejected(self):
        write_project(self.tmp, make_min_prd(schema="9.9.9"))
        self.assertFalse(self.check()["ok"])


class TestFiguresRemoved(TempDirMixin, unittest.TestCase):
    def test_capture_and_figure_commands_are_gone(self):
        for command in ("captures", "figures"):
            argv = ["prd_tool.py", command, "--prd", str(self.tmp / "PRD.md")]
            with self.assertRaises(SystemExit):
                with contextlib.redirect_stderr(io.StringIO()):
                    with unittest.mock.patch("sys.argv", argv):
                        tool.main()

    def test_four_commands_are_accepted(self):
        with contextlib.redirect_stdout(io.StringIO()):
            with unittest.mock.patch("sys.argv", ["prd_tool.py", "--help"]):
                with self.assertRaises(SystemExit):
                    tool.main()

    def test_no_figure_helpers_left(self):
        for name in ("CAPTURE_DIR", "CAPTURE_MANIFEST", "FIGURE_DIR", "FIGURE_MANIFEST",
                     "load_capture_manifest", "load_figure_manifest", "check_captures",
                     "check_figures", "check_layout_evidence", "writeback_captures",
                     "init_capture_spec", "scan_figures", "init_figure_dirs",
                     "reject_embedded_images", "figure_pointer", "figure_label",
                     "int_fields_for", "INT_FIELDS_V10", "wants_capture_fields",
                     "wants_figure_sources", "wants_figures_outside_text"):
            self.assertFalse(hasattr(tool, name), f"{name} 应随图证机制一起删除")

    def test_source_has_no_capture_code(self):
        """代码层不许残留图证实现的任何符号；文档层允许「v2.0.0 已拆除」这类说明。"""
        source = TOOL.read_text(encoding="utf-8")
        for token in ("CAPTURE_DIR", "CAPTURE_MANIFEST", "CAPTURE_SPEC", "CAPTURE_SCHEMA",
                      "FIGURE_DIR", "FIGURE_MANIFEST", "FIGURE_SCHEMA", "FIGURE_KINDS",
                      "prd_capture", "figurebook", "load_capture_manifest",
                      "load_figure_manifest", "def check_captures", "def check_figures",
                      "def writeback_captures", "def scan_figures", "def init_figure_dirs",
                      "def init_capture_spec", "def parse_viewports",
                      "def reject_embedded_images", "def figure_pointer"):
            self.assertNotIn(token, source, f"prd_tool.py 仍残留「{token}」")

    def test_documented_commands_are_four(self):
        doc = tool.__doc__ or ""
        commands = sorted(set(re.findall(r"(?m)^  (\w+)\s+\S", doc)))
        self.assertEqual(commands, ["bump", "check", "conclusion", "init"])

    def test_twelve_column_table_passes_ready(self):
        write_project(self.tmp, make_min_prd(fields=INT_FIELDS_V2))
        self.assertTrue(self.check()["ok"])

    def test_fifteen_column_legacy_doc_still_passes(self):
        """旧文档交互表带 动效/图证/实测 三列：多出的列被忽略，不判红。"""
        write_project(self.tmp, make_min_prd(schema="1.6.0", fields=INT_FIELDS_V15))
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(result["schema_version"], "1.6.0")

    def test_legacy_figure_pointer_line_is_ignored(self):
        """1.x 文档里的「**图证**：…png」指针行按未知内容忽略，不报错。"""
        prd = make_min_prd(schema="1.6.0", fields=INT_FIELDS_V15,
                           extra_body="**图证**：captures/fig/需求-001.png（原型实测）")
        write_project(self.tmp, prd)
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])

    def test_receipt_has_no_figure_talk(self):
        write_project(self.tmp, conclusion=True)
        result = tool.check_prd(self.tmp / "PRD.md", "ready")
        receipt = tool.make_receipt(self.tmp / "PRD.md", "ready", result)
        blob = json.dumps(receipt, ensure_ascii=False)
        for token in ("图证", "captures", "figures", "截图", "示意图"):
            self.assertNotIn(token, blob)
        self.assertNotIn(token, json.dumps(result["not_checked"], ensure_ascii=False))

    def test_counts_have_no_figure_keys(self):
        write_project(self.tmp)
        counts = self.check()["counts"]
        self.assertNotIn("captures", counts)
        self.assertNotIn("figures", counts)


# ---------------------------------------------------------------------------
# Task 3：原型多文件 + 草案豁免 + bump 多文件
# ---------------------------------------------------------------------------

class TestMultiFilePrototype(TempDirMixin, unittest.TestCase):
    def two_page(self, prototype="prototype.html"):
        return make_min_prd(prototype=f'"{prototype}"',
                            pages=(PAGE_ROW_001, PAGE_ROW_002))

    def test_markers_aggregate_across_files(self):
        write_project(self.tmp, self.two_page(prototype="prototype.html"),
                      prototype={
                          "prototype.html": prototype_html(markers=""),
                          "prototype.list.html": prototype_html(
                              page_id="页面-001",
                              markers=' data-req-id="需求-001" data-int-id="交互-001" data-ac-id="验收-001"'),
                          "prototype.detail.html": prototype_html(
                              page_id="页面-002", markers=' data-ac-id="验收-002"'),
                      })
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])

    def test_page_file_without_page_id_is_error(self):
        write_project(self.tmp, self.two_page(),
                      prototype={
                          "prototype.html": prototype_html(markers=""),
                          "prototype.list.html": prototype_html(
                              page_id=None, markers=' data-req-id="需求-001"'
                                                    ' data-int-id="交互-001"'
                                                    ' data-ac-id="验收-001"'),
                      })
        result = self.check()
        self.assertFalse(result["ok"])
        self.assertTrue(any("data-page-id" in e for e in result["errors"]), result["errors"])

    def test_undeclared_page_id_is_error(self):
        write_project(self.tmp, self.two_page(),
                      prototype={
                          "prototype.html": prototype_html(markers=""),
                          "prototype.list.html": prototype_html(
                              page_id="页面-099",
                              markers=' data-req-id="需求-001" data-int-id="交互-001"'
                                      ' data-ac-id="验收-001"'),
                      })
        result = self.check()
        self.assertFalse(result["ok"])
        self.assertTrue(any("页面-099" in e for e in result["errors"]), result["errors"])

    def test_declared_page_without_file_is_error(self):
        write_project(self.tmp, self.two_page(),
                      prototype={
                          "prototype.html": prototype_html(markers=""),
                          "prototype.list.html": prototype_html(
                              page_id="页面-001",
                              markers=' data-req-id="需求-001" data-int-id="交互-001"'
                                      ' data-ac-id="验收-001"'),
                      })
        result = self.check()
        self.assertFalse(result["ok"])
        self.assertTrue(any("页面-002" in e for e in result["errors"]), result["errors"])

    def test_index_page_is_exempt_from_fidelity_checks(self):
        """索引页是纯链接导航：没有交互事件、样式规则也少，两项高保真检查必须豁免。"""
        write_project(self.tmp, self.two_page(),
                      prototype={
                          "prototype.html": prototype_html(script=False, style_rules=False,
                                                          markers=""),
                          "prototype.list.html": prototype_html(
                              page_id="页面-001",
                              markers=' data-req-id="需求-001" data-int-id="交互-001" data-ac-id="验收-001"'),
                          "prototype.detail.html": prototype_html(
                              page_id="页面-002", markers=' data-ac-id="验收-002"'),
                      })
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])

    def test_single_file_still_needs_interaction(self):
        write_project(self.tmp, make_min_prd(prototype='"prototype.html"'),
                      prototype={"prototype.html": prototype_html(script=False)})
        result = self.check()
        self.assertFalse(result["ok"])
        self.assertTrue(any("交互事件" in e for e in result["errors"]), result["errors"])

    def test_prototype_files_helper(self):
        write_project(self.tmp, self.two_page(),
                      prototype={
                          "prototype.html": prototype_html(markers=""),
                          "prototype.detail.html": prototype_html(page_id="页面-002", markers=""),
                          "prototype.list.html": prototype_html(page_id="页面-001", markers=""),
                      })
        names = [p.name for p in tool.prototype_files(self.tmp)]
        self.assertEqual(names, ["prototype.html", "prototype.detail.html",
                                 "prototype.list.html"])

    def test_page_links_are_not_external_resources(self):
        """索引页链到页面文件是页面间跳转，不该被判成「引用了外部资源」。"""
        index = prototype_html(script=False, style_rules=False, markers="").replace(
            '<div class="wrap">',
            '<div class="wrap">\n<div class="nav"><a href="prototype.list.html">列表</a>'
            '<a href="prototype.detail.html?id=1">详情</a></div>')
        write_project(self.tmp, self.two_page(),
                      prototype={
                          "prototype.html": index,
                          "prototype.list.html": prototype_html(
                              page_id="页面-001",
                              markers=' data-req-id="需求-001" data-int-id="交互-001"'
                                      ' data-ac-id="验收-001"'),
                          "prototype.detail.html": prototype_html(
                              page_id="页面-002", markers=' data-ac-id="验收-002"'),
                      })
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])
        self.assertFalse(any("外部资源" in e for e in result["errors"]))

    def test_cdn_script_is_still_external(self):
        """真正的 CDN 引用仍然要报错——放行的是页面链接，不是所有 href。"""
        bad = prototype_html().replace(
            "</head>", '<script src="https://cdn.example.com/x.js"></script>\n</head>')
        write_project(self.tmp, make_min_prd(prototype='"prototype.html"'),
                      prototype={"prototype.html": bad})
        result = self.check()
        self.assertFalse(result["ok"])
        self.assertTrue(any("外部资源" in e for e in result["errors"]), result["errors"])

    def test_example_ships_index_and_two_pages(self):
        """仓库里的 feedback-board 样例就是多文件原型：索引页 + 两个页面文件。"""
        names = sorted(p.name for p in EXAMPLE.glob("prototype*.html"))
        self.assertEqual(names, ["prototype.detail.html", "prototype.html",
                                 "prototype.list.html"])
        result = tool.check_prd(EXAMPLE / "PRD.md", "ready")
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(result["warnings"], [])


class TestDraftPrototype(TempDirMixin, unittest.TestCase):
    def test_draft_entry_passes_ready_with_warning(self):
        write_project(self.tmp, make_min_prd(prototype='"prototype.html"'),
                      prototype={"prototype.html": prototype_html(
                          prd_id="draft", version=None)})
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])
        self.assertTrue(any("草案" in w for w in result["warnings"]), result["warnings"])

    def test_draft_skips_marker_closure(self):
        """草案不做标记闭合：一个 data-* 标记都没有也不该报「缺少标记」。"""
        write_project(self.tmp, make_min_prd(prototype='"prototype.html"'),
                      prototype={"prototype.html": prototype_html(
                          prd_id="draft", version=None, markers="")})
        result = self.check()
        self.assertTrue(result["ok"], result["errors"])
        self.assertFalse(any("缺少" in e and "标记" in e for e in result["errors"]))

    def test_is_draft_helper(self):
        self.assertTrue(tool.is_draft('<body data-prd-id="draft">'))
        self.assertFalse(tool.is_draft('<body data-prd-id="demo-min">'))

    def test_non_draft_version_mismatch_is_error(self):
        write_project(self.tmp, make_min_prd(prototype='"prototype.html"'),
                      prototype={"prototype.html": prototype_html(version="0.9.9")})
        result = self.check()
        self.assertFalse(result["ok"])
        self.assertTrue(any("data-prd-version" in e for e in result["errors"]),
                        result["errors"])


class TestBumpMultiFile(TempDirMixin, unittest.TestCase):
    def test_bump_updates_every_prototype_file(self):
        write_project(self.tmp,
                      make_min_prd(prototype='"prototype.html"',
                                   pages=(PAGE_ROW_001, PAGE_ROW_002)),
                      prototype={
                          "prototype.html": prototype_html(markers=""),
                          "prototype.list.html": prototype_html(
                              page_id="页面-001",
                              markers=' data-req-id="需求-001" data-int-id="交互-001" data-ac-id="验收-001"'),
                          "prototype.detail.html": prototype_html(
                              page_id="页面-002", markers=' data-ac-id="验收-002"'),
                      })
        result = tool.bump_version(self.tmp / "PRD.md", "0.2.0", "2026-11-04", "修订",
                                   "补齐导入边界（需求-001）", "决策-001")
        self.assertTrue(result["ok"])
        for name in ("prototype.html", "prototype.list.html", "prototype.detail.html"):
            html = (self.tmp / name).read_text(encoding="utf-8")
            self.assertIn('data-prd-version="0.2.0"', html, name)
        self.assertNotIn("0.1.0", (self.tmp / "prototype.detail.html").read_text(encoding="utf-8"))

    def test_bump_leaves_draft_untouched(self):
        write_project(self.tmp, make_min_prd(prototype='"prototype.html"'),
                      prototype={"prototype.html": prototype_html(prd_id="draft", version=None)})
        before = (self.tmp / "prototype.html").read_text(encoding="utf-8")
        result = tool.bump_version(self.tmp / "PRD.md", "0.2.0", "2026-11-04", "修订",
                                   "补齐导入边界（需求-001）", "决策-001")
        self.assertTrue(result["ok"])
        after = (self.tmp / "prototype.html").read_text(encoding="utf-8")
        self.assertEqual(before, after)
        self.assertNotIn("data-prd-version", after)

    def test_bump_updates_intro_anchor(self):
        write_project(self.tmp)
        tool.bump_version(self.tmp / "PRD.md", "0.2.0", "2026-11-04", "修订",
                          "补齐导入边界（需求-001）", "决策-001")
        intro = (self.tmp / "项目简介.md").read_text(encoding="utf-8")
        self.assertIn("PRD.md（0.2.0）", intro)


if __name__ == "__main__":
    unittest.main()
