"""端到端 smoke：反向通路（原型 → PRD）的机械部分。

模拟真实场景：手上有几份原型产物，还没有 PRD。验证
  ① 材料目录直接 init 会被拒（防覆盖边界没破）
  ② init 到干净子目录能过
  ③ 拷问结论拷进子目录后 conclusion 门能过
  ④ 最小 PRD 在 draft 档能跑出结构化结果
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TOOL = Path(sys.argv[1]).resolve()
PY = [sys.executable]


def run(*args, cwd=None):
    proc = subprocess.run(PY + [str(TOOL)] + list(args), cwd=cwd,
                          capture_output=True, text=True, encoding="utf-8")
    try:
        payload = json.loads(proc.stdout)
    except ValueError:
        payload = {"raw_stdout": proc.stdout, "raw_stderr": proc.stderr}
    return proc.returncode, payload


root = Path(tempfile.mkdtemp(prefix="prd-reverse-smoke-"))
try:
    material = root / "材料"
    material.mkdir()
    (material / "反馈看板-v2.html").write_text(
        "<!DOCTYPE html><html lang=\"zh-CN\"><head><meta name=\"viewport\" "
        "content=\"width=device-width,initial-scale=1\"><title>demo</title></head>"
        "<body><h1>反馈看板</h1><button>提交</button></body></html>", encoding="utf-8")
    (material / "需求稿.docx.txt").write_text("口述需求记录", encoding="utf-8")

    checks = []

    # ① 材料目录直接 init 必须被拒
    code, out = run("init", "--dir", str(material), "--slug", "feedback-board",
                    "--title", "团队反馈看板", "--date", "2026-11-03")
    checks.append(("材料目录 init 被拒", code == 1 and out.get("ok") is False,
                   out.get("errors", [""])[0][:60]))

    # ② 建干净子目录再 init
    product = root / "产物"
    code, out = run("init", "--dir", str(product), "--slug", "feedback-board",
                    "--title", "团队反馈看板", "--date", "2026-11-03")
    checks.append(("干净子目录 init 成功", code == 0 and out.get("ok") is True,
                   ",".join(out.get("files", []))))

    # ③ 结论拷进同一目录并过结论门
    example = Path(__file__).resolve().parents[1] / "examples" / "feedback-board"
    shutil.copy2(example / "拷问结论.md", product / "拷问结论.md")
    code, out = run("conclusion", "--file", str(product / "拷问结论.md"), "--gate", "ready")
    checks.append(("拷问结论过门", code == 0 and out.get("ok") is True,
                   f"doc_mode={out.get('doc_mode')}"))

    # ④ 拷入样例 PRD 与原型，确认 draft 档能跑出结构结果
    for name in ("PRD.md", "项目简介.md", "prototype.html",
                 "prototype.list.html", "prototype.detail.html"):
        shutil.copy2(example / name, product / name)
    code, out = run("check", "--prd", str(product / "PRD.md"), "--gate", "draft")
    checks.append(("样例 PRD 在 draft 档可读", "schema_version" in out or "errors" in out,
                   f"ok={out.get('ok')} errors={len(out.get('errors') or [])}"))

    # ⑤ 反向识别后 PRD 里出现了页面-002：页面 ↔ 页面文件对齐能抓住缺文件
    (product / "prototype.detail.html").unlink()
    code, out = run("check", "--prd", str(product / "PRD.md"), "--gate", "ready")
    hit = [e for e in out.get("errors", []) if "页面-002" in e]
    checks.append(("删掉详情页会被抓出来", code == 1 and bool(hit), hit[0][:70] if hit else "无"))

    width = max(len(name) for name, _, _ in checks)
    failed = 0
    for name, ok, detail in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name.ljust(width)}  {detail}")
        failed += 0 if ok else 1
    print(f"\n{len(checks) - failed}/{len(checks)} 通过")
    sys.exit(1 if failed else 0)
finally:
    shutil.rmtree(root, ignore_errors=True)
