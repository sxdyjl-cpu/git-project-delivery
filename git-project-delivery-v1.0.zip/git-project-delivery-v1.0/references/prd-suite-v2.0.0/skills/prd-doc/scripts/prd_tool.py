#!/usr/bin/env python3
"""prd-tools v2.0.0 机械检查（校验 PRD 契约 v2.0.0；旧号 1.0.0 / 1.1.0 / 1.2.0 / 1.3.0 / 1.4.0 / 1.6.0 仍接受）。

This tool never invents or grants human approval.

本脚本是 prd-doc / prd-prototype 两个技能共用的机械契约层。
两份副本内容必须完全一致（打包脚本会断言哈希），改一处就要两处一起改。

版本号说明：1.0.0 是**编号重置**，不是第一次发布。套件此前用 5.x 迭代过九个版本，
功能已到可正式交付的程度，对外统一收成 1.0.0 这一条线。PRD 文档格式
（`schema_version`）此前是 5.0.0，与套件版本同批重置为 1.0.0——**结构一个字段都没变**，
旧 5.0.0 文档只需把 frontmatter 那一行改成 `1.0.0` 即可通过 `check`。
契约版本与工具版本仍分开走：只有 PRD 文档结构本身变了，`schema_version` 才跟着升。

2.0.0 是一次**减法**：图证层（采集器、captures/、figures/、图证册、交互表三列）整体拆除，
PRD 回到纯文字文档，视觉呈现交给原型 HTML 自己。理由一句话——图一旦进文档，
就要同时维护「文档里的指针」和「文件系统里的图」两份真相，而真正要看界面的人是去开原型的。

命令：
  init  --project <项目根> --slug --title --date [--mode 新建|增量]
         生成 PRD.md 与人类摘要（项目简介.md / 决策摘要.md）骨架；
         产物落在 <项目根>/docs/product/<slug>/
  init  --dir <产物目录> --slug --title --date
         同上，但直接指定产物目录，脚本不再拼任何路径（两种给法必须且只能给一个）
  conclusion --file [--gate draft|ready] [--receipt]
         校验拷问结论.md 的四分类结构与必备字段
  check --prd [--gate draft|ready] [--diagnose] [--receipt]
         校验 PRD 结构、追溯 ID、版本记录、人类摘要、原型标记与保真底线
  bump  --prd --version --date --type --summary [--decisions]
         追加版本记录行、升 frontmatter version，并同步摘要锚点与原型版本标记

脚本只做机械检查，不能证明确认真实、方案合理或验收充分——这些仍需 Agent 与用户评审。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import date, datetime
from pathlib import Path

SCHEMA_VERSIONS = ("1.0.0", "1.1.0", "1.2.0", "1.3.0", "1.4.0", "1.6.0", "2.0.0")
SCHEMA_VERSION = "2.0.0"
# 1.2.0 是统一前的同一个契约，保留为旧号；统一前的 1.1.0 文档没有阅读层，
# 按存量宽容判，避免换工具就把旧项目判红。
# 1.3.0 起图源分三类（原型实测 / 外部原型 / 自绘示意图），只在新文档上硬判。
# 1.4.0 起 PRD 正文不再内嵌任何图片：图单独归档、单独成册，PRD 只留文字指针。
# 1.5.x 是统一前的内部迭代号（同号归档包里 schema 写的是 1.2.0），对外不复用，
# 所以这一版直接从 1.3.0 跳到 1.6.0，避免与归档包重名。
# 1.6.0 起「没有材料」有唯一合法写法：`未提供：原因` / `不适用：原因`。裸留空、
# 裸「—」、写「待确认」都不算——前者读者分不清是「没有」还是「漏了」，后者是
# 「还没写」。同一条规则也管住了「为了填满而编造」。
# 2.0.0 把上面 1.3.0–1.4.0 铺开的那套图证层**整体拆掉**：PRD 回到纯文字文档，
# 交互表回 12 字段，视觉呈现交给原型 HTML 本身。存量 1.x 文档里残留的图证列与
# 指针行按「未知内容忽略」处理，既不判红也不校验。
READABLE_MARKER = "## 一页摘要"


def is_unified_contract(meta, body=""):
    """当前契约 2.0.0。旧号 1.2.0 / 1.3.0 / 1.4.0 / 1.6.0 等价；统一前的 1.1.0（无阅读层）按存量判。"""
    value = str(meta.get("schema_version") or "")
    if value in ("1.2.0", "1.3.0", "1.4.0", "1.6.0", "2.0.0"):
        return True
    if value == "1.1.0":
        return READABLE_MARKER in (body or "")
    return False
DOC_MODES = ("新建", "增量")

# --- 拷问结论契约（prd-doc 第 0 步的产出，后续步骤与反向识别的输入）--------
# 四分类是硬结构，顺序固定：prd-doc 按这个顺序把前两类转成 决策-xxx / 假设-xxx。
CONCLUSION_SECTIONS = ("已定决策", "采纳的假设", "未解决的问题", "被驳的推荐")
# 每一类里每条必须写清的字段（中文标签）。缺了就是「没问清楚」，不是格式小毛病。
CONCLUSION_FIELDS = {
    "已定决策": ("依据", "确认"),
    "采纳的假设": ("默认值", "影响面", "验证方法"),
    "未解决的问题": ("阻塞", "下一步"),
    "被驳的推荐": ("用户改成", "原因"),
}
# 头部元信息行：> 日期：… ｜ 轮次：… ｜ 前沿：… ｜ doc_mode: …
CONCLUSION_META_RE = re.compile(r"^>\s*(?:日期|轮次|前沿|doc_mode)", re.M)
CONCLUSION_MODE_RE = re.compile(r"doc_mode\s*[:：]\s*(新建|增量)")
CONCLUSION_DATE_RE = re.compile(r"日期\s*[:：]\s*(\d{4}-\d{2}-\d{2})")
CONCLUSION_ROUND_RE = re.compile(r"轮次\s*[:：]\s*(\d+)")
CONCLUSION_FRONTIER_RE = re.compile(r"前沿\s*[:：]\s*(\S+)")
CONCLUSION_FILE = "拷问结论.md"
EXPLORE_FILE = "探索记录.md"
PRD_FILE = "PRD.md"
# init 允许目录里已经存在的文件。这两份都是 PRD 的原料，不是要被覆盖的产物：
# 「先落盘、后 init」在用户手上是先有结论/探索记录的（问完、选完方向才来成文），
# 把它们当成「目录非空」拒绝，会让成文这一步 100% 失败（实测 RC=1）。
# 其它任何文件（材料、代码、旧文档）仍然拒绝，防覆盖的安全边界不动。
INIT_KEEPABLE = {CONCLUSION_FILE, EXPLORE_FILE}
# 「无。」「无——…」这类正常写法不是空节；只把小节体一个字都没有当空。
CONCLUSION_NONE_RE = re.compile(r"^\s*(?:无|没有|空)\s*(?:[。.；;—\-（(].*)?$", re.S)

# ID 前缀与所属章节一一对应。
ID_PREFIXES = {
    "页面": 4, "需求": 5, "交互": 6, "数据": 7, "非功能约束": 9,
    "验收": 10, "问题": 11, "假设": 11, "决策": 12, "来源": 12,
}
# 已有项目的增量 PRD 只写本次变化，不重复完整产品地图。
DELTA_HEADINGS = {
    1: "变更摘要",
    2: "用户行为与页面变化",
    3: "数据、权限与接口影响",
    4: "异常、边界与兼容性",
    5: "验收标准",
    6: "决策、来源与变更",
}
DELTA_ID_PREFIXES = {
    "页面": 2, "需求": 2, "交互": 2, "数据": 3, "非功能约束": 4,
    "验收": 5, "问题": 6, "假设": 6, "决策": 6, "来源": 6,
}
# 长的前缀排前面，保证「非功能约束-001」不被「约束」类短词抢先匹配。
_ID_ALT = "|".join(sorted(set(ID_PREFIXES) | set(DELTA_ID_PREFIXES), key=len, reverse=True))
# 边界只挡 ASCII 字母、数字与连字符：中文没有词间空格，用 \b 会让
# 「见需求-001」「该交互-002」这类紧贴汉字的引用漏抽，导致双向映射校验静默失效。
# 顿号、空格、换行、竖线都不是 ASCII 字符，天然构成合法边界。
ID_RE = re.compile(rf"(?<![A-Za-z0-9-])(?:{_ID_ALT})-\d{{3,}}(?![A-Za-z0-9])")
ID_ANY_RE = re.compile(rf"(?:{_ID_ALT})-[^\s|]+")
PLACEHOLDER = re.compile(r"\{\{[^}]+\}\}|\b(?:TODO|TBD)\b|待确认|待补充|待决定|未填写")
# 1.6.0：没有材料时的两种合法写法。冒号后的原因至少两个字——「未提供：」和光秃秃的
# 「未提供」读者分不出是「确实没有」还是「写到一半」。
EMPTY_CLAIM_WORDS = ("未提供", "不适用")
EMPTY_CLAIM_RE = re.compile(r"(未提供|不适用)\s*([：:]?)\s*([^\s|，。；、）)]*)")
EMPTY_CLAIM_MIN_REASON = 2
# 一页摘要这七行是任何 PRD 都躲不开的，行名与模板一致。
SUMMARY_ROWS = ("一句话", "问题", "用户", "方案", "成功指标", "本期不做", "最大风险")
# 其中前四行讲的是产品本体：缺了它就不是「材料不足」，是这件事还没想清楚，
# 所以不接受「未提供」，只接受一句实话。
SUMMARY_CORE_ROWS = ("一句话", "问题", "用户", "方案")
SLUG_RE = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*")
HEADINGS = {
    1: "背景、目标与成功指标", 2: "用户、角色与场景", 3: "方案与范围",
    4: "页面与用户流程", 5: "功能需求", 6: "交互与状态",
    7: "数据、权限与业务规则", 8: "视觉、布局与适配", 9: "非功能与运行约束",
    10: "验收标准", 11: "开放问题与假设", 12: "决策、来源与变更",
}
# 当前契约（1.1.0）第 11 节是「风险、依赖与开放问题」；统一前的 1.1.0 与 1.0.0 仍按 HEADINGS 判。
HEADINGS_V12 = dict(HEADINGS)
HEADINGS_V12[11] = "风险、依赖与开放问题"

# 1.4.0 按通行 PRD 结构重排：背景 → 目标 → 用户 → 方案 → 范围 → 功能详述 → 交互
# → 数据 → 非功能 → 验收 → 风险 → 埋点 → 规划 → 决策。参照的是飞书产品需求文档
# 模板（版本信息 / 变更日志 / 文档说明 / 需求背景 / 需求范围 / 功能详细说明 /
# 非功能需求 / 埋点 / 项目规划 / 附录），但**去掉了其中的「交互原型图」与「示意图」
# 部分**——图不进正文，只留指针（见「PRD 不内嵌图」）。
# 版本信息与变更日志不进正文：frontmatter 已有 version / updated_at / status，
# 版本记录在第 14 节，重复一遍就是同一件事的两种说法。
HEADINGS_V14 = {
    1: "需求背景",
    2: "目标与成功指标",
    3: "用户、角色与场景",
    4: "方案与范围",
    5: "需求范围与用户流程",
    6: "功能详细说明",
    7: "交互与状态",
    8: "数据、权限与业务规则",
    9: "非功能需求",
    10: "验收标准",
    11: "风险、依赖与开放问题",
    12: "非功能以外的交付项：埋点",
    13: "项目规划",
    14: "决策、来源与变更",
}
# 1.4.0 的 ID 归属：按 14 节重排后的真实位置写死，不靠推导。
#   页面 → 第 5 节「需求范围与用户流程」
#   需求 / 交互 → 第 6 / 7 节
#   数据 → 第 8 节；非功能约束 → 第 9 节
#   验收 → 第 10 节；问题 / 假设 → 第 11 节
#   决策 / 来源 → 第 14 节
# 这里全部重写而不是复制，是因为老映射里「页面: 4」在新结构下指向「方案与范围」，
# 照着抄会把页面表判成定错章节（实测撞过）。
ID_PREFIXES_V14 = {
    "页面": 5, "需求": 6, "交互": 7, "数据": 8, "非功能约束": 9,
    "验收": 10, "问题": 11, "假设": 11, "决策": 14, "来源": 14,
}
FIELDS = {
    "需求": ["ID", "优先级", "要求与边界", "来源/决策", "验收"],
    "非功能约束": ["ID", "约束与验证方法", "来源/决策", "验收"],
    "验收": ["ID", "关联需求", "类型"],
    "问题": ["ID", "类型", "影响需求", "影响级别", "内容/理由", "状态", "处理方案/负责人"],
    "假设": ["ID", "类型", "影响需求", "影响级别", "内容/理由", "状态", "处理方案/负责人"],
    "决策": ["ID", "决策", "依据/来源", "确认者与证据", "影响范围"],
    "来源": ["ID", "来源", "位置与摘要", "可信度/限制"],
}
# 验收三列：中文是默认写法；Given/When/Then 作为旧版兼容继续接受。
ACCEPTANCE_FIELDS_ZH = ("前提", "操作", "预期")
ACCEPTANCE_FIELDS_EN = ("Given", "When", "Then")
INT_FIELDS = {"关联需求", "页面/组件", "触发与前置状态", "输入与校验", "权限",
              "处理中反馈", "成功结果", "失败与恢复", "空态/无权限", "重复/并发", "取消/退出",
              "验收"}
# 2.0.0 起交互表固定回 12 字段：动效 / 图证 / 实测 三列随图证机制一起拆除。
# 旧文档（1.0.0–1.6.0）里多出来的列按「未知内容忽略」处理，不判红——换工具不该把
# 存量项目判错。动效如需表达，写在该交互的人话段落里，不再作为机械校验列。
# v1.0 去掉了交付对象分支：只剩「评审/自用」一种交付形态，不再有 delivery 字段。
REQUIRED_META = (
    "schema_version", "prd_id", "title", "version", "status", "updated_at",
    "prototype", "doc_mode",
)
CHANGE_TYPES = ("初版", "修订", "新增", "破坏性")
PRD_STATUS = ("草稿", "评审中", "已确认")
ASM_TYPES = ("问题", "假设")
ASM_LEVELS = ("阻塞", "非阻塞")
ASM_STATES = ("待处理", "已解决", "已采纳", "已延后")
# 契约明文禁止的空话。只收契约与质量门原文点名的短语，避免误伤合法描述。
FORBIDDEN_VAGUE = ("更新内容", "优化体验", "调整若干", "若干修改")
# AI 腔 / 企业黑话词表：只收语义上一定言之无物、且在正常中文技术写作里不必出现的词。
# 「闭环」「对齐」「链路」这类在本套件语境里有正常用法，故意不收，避免误报把警告变成噪音。
AI_TONE = (
    "赋能", "抓手", "一站式", "无缝衔接", "无缝对接", "数智化", "极致体验",
    "打通闭环", "降本增效", "提质增效", "组合拳", "全方位赋能", "生态化反",
)
# 编号至少三位：1–2 位的写法（需求-9）会被 ID_RE 的 \d{3,} 漏掉，单独抓出来报错
SHORT_ID_RE = re.compile(rf"(?<![A-Za-z0-9-])(?:{_ID_ALT})-\d{{1,2}}(?![0-9])")
# 人类摘要：新建产品用“项目简介”，已有项目增量用“决策摘要”。
INTRO_FILE = "项目简介.md"
SUMMARY_FILE = "决策摘要.md"
SUMMARY_SECTIONS = ("为什么做", "这次改什么", "不改什么", "需要决策", "怎么判断成功")
SUMMARY_MIN = 300
SUMMARY_MAX = 1200
# 模板指引里的原话。写完没删就提醒一句——留着「该怎么写」给谁看。
INTRO_GUIDE = "写完把这段指引删掉"
# 四件必讲的事，各占一节。节内是散文，节间是小标题——不是表格。
INTRO_SECTIONS = ("背景", "痛点", "大致思路", "怎么解决")
# 简介的占位词口径比 PRD 宽：PRD 是正式文档，「待确认」是占位；简介是白话散文，
# 正文里说「上线时间待确认」是正常叙述，不能拦。只查模板形态：
# 行首的「待确认：」类、{{...}}、TODO/TBD。
INTRO_PLACEHOLDER = re.compile(
    r"\{\{[^}]+\}\}|\b(?:TODO|TBD)\b|^[ \t>*-]*(?:待确认|待补充|待决定)[：:]|^[ \t>*-]*未填写",
    re.M)
# 建议篇幅（字）。偏短偏长都只给警告，不拦截交付。
INTRO_MIN = 500
INTRO_MAX = 1000
# 「确认者与证据」整格只写这些词时，等于没有证据
EVIDENCE_PLACEHOLDER = ("待定", "待确认", "待补充", "待决定", "未填写", "TODO", "TBD", "-", "—")

# v1.0 要求每节先给一句人话结论；旧版文档不通过。
SECTION_CONCLUSION = re.compile(
    r"(?m)^\s*>?\s*(?:\*\*)?(?:本章结论|一句话结论)\s*[：:]\s*\S+"
)
# 人类摘要头部的版本锚点。v1 只有三处联动：PRD version / 摘要锚点 / 原型 data-prd-version。
ANCHOR_RE = re.compile(r"PRD[：:]\s*PRD\.md\s*[（(]([^）)]*)[）)]")
# 原型高保真底线（机械可判的部分，判决见 prd-prototype 的 prototype-guide.md）。
#
# 这几个正则都得咬住「标签真的开在这里」：
# `<style\b` 会把 `<style-disabled>` 也算成内联样式（`-` 是非单词字符，\b 成立），
# 于是把 <style> 改名成别的标签也照样过关——那样的检查等于没做。
EXTERNAL_RESOURCE = re.compile(
    r"""(?:src|href)\s*=\s*["'](?!#|data:|mailto:|javascript:)([^"']+)["']""", re.I)
STYLE_OPEN_RE = re.compile(r"<style(?:\s[^>]*)?>", re.I)
STYLE_CLOSE_RE = re.compile(r"</style\s*>", re.I)
SCRIPT_OPEN_RE = re.compile(r"<script(?:\s[^>]*)?>", re.I)
SCRIPT_CLOSE_RE = re.compile(r"</script\s*>", re.I)
DRIVE_EVENT_RE = re.compile(r"addEventListener\s*\(|\bon(?:click|input|change|submit)\s*=", re.I)
# 门禁不该被注释里的字样骗过：一行被注掉的 addEventListener 不是交互。
HTML_COMMENT_RE = re.compile(r"(?s)<!--.*?-->")
JS_COMMENT_RE = re.compile(r"/\*.*?\*/|//[^\n]*", re.S)
# 一条可用的样式规则至少要这么多个声明块；低于它就只是骨架，没做视觉设计。
MIN_STYLE_RULES = 20


def inline_block(html, open_re, close_re):
    """取出内联标签之间的内容；标签缺失时返回 None。

    只认真正的开标签（后面紧跟 `>` 或属性），并取第一个闭合标签前的内容。
    """
    m = open_re.search(html)
    if not m:
        return None
    end = close_re.search(html, m.end())
    return html[m.end():end.start()] if end else html[m.end():]


def ids(value, prefixes=None):
    found = set(ID_RE.findall(str(value or "")))
    return {x for x in found if prefixes is None or x.split("-")[0] in prefixes}


def doc_mode(meta):
    """供内部评分使用；check_prd 会把缺失的 doc_mode 单独报错。"""
    value = str(meta.get("doc_mode") or DOC_MODES[0])
    return value if value in DOC_MODES else DOC_MODES[0]


def headings_for(meta, body=""):
    if doc_mode(meta) == "增量":
        return DELTA_HEADINGS
    if schema_at_least(meta, "1.4.0"):
        return HEADINGS_V14
    if is_unified_contract(meta, body):
        return HEADINGS_V12
    return HEADINGS


def prefixes_for(meta):
    if doc_mode(meta) == "增量":
        return DELTA_ID_PREFIXES
    if schema_at_least(meta, "1.4.0"):
        return ID_PREFIXES_V14
    return ID_PREFIXES


def human_file_for(meta):
    return SUMMARY_FILE if doc_mode(meta) == "增量" else INTRO_FILE


def schema_is_current(meta):
    """结构/可读性检查适用的最低版本：1.1.0 起（1.0.0 存量文档不追新规则）。"""
    return schema_at_least(meta, "1.1.0")


def schema_at_least(meta, version):
    """文档的 schema 是否 >= 给定版本。"""
    value = str(meta.get("schema_version") or "")
    if value not in SCHEMA_VERSIONS:
        return False
    return tuple(int(x) for x in value.split(".")) >= tuple(int(x) for x in version.split("."))


def hard_gate(gate):
    """ready 是交付前硬门；draft 只做结构预警。"""
    return gate == "ready"


def unfenced(text):
    lines, fence = [], None
    for line in text.splitlines():
        m = re.match(r"^\s*(`{3,}|~{3,})", line)
        if m:
            marker = m.group(1)
            if fence is None:
                fence = marker
            elif marker[0] == fence[0] and len(marker) >= len(fence):
                fence = None
            lines.append("")
        else:
            lines.append(line if fence is None else "")
    return "\n".join(lines)


def load_frontmatter(path):
    """解析平铺键值的 YAML frontmatter；仅支持本契约的平铺格式。"""
    text = Path(path).read_text(encoding="utf-8-sig")
    m = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", text, re.S)
    if not m:
        raise ValueError("缺少合法 frontmatter（首行 --- ... ---）")
    meta = {}
    for number, line in enumerate(m.group(1).splitlines(), start=2):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if ":" not in stripped:
            raise ValueError(f"frontmatter 第 {number} 行不是键值对：{stripped!r}")
        key, value = stripped.split(":", 1)
        key, value = key.strip(), value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            quote, value = value[0], value[1:-1]
            # YAML 单引号字面量用 '' 表示一个字面单引号；双引号值在本契约中不含转义。
            if quote == "'":
                value = value.replace("''", "'")
        if value in ("null", "~"):
            value = None
        meta[key] = value
    if not isinstance(meta, dict) or not meta:
        raise ValueError("frontmatter 必须是键值映射")
    return meta, text, unfenced(text[m.end():])


def load_doc(path):
    meta, text, body = load_frontmatter(path)
    sections, current = {}, None
    for line in body.splitlines():
        heading = re.match(r"^##\s+(\d+)\.\s+(.+?)\s*$", line)
        if heading:
            current = int(heading.group(1))
            if current in sections:
                raise ValueError(f"重复章节 {current}")
            sections[current] = {"title": heading.group(2), "lines": []}
        elif current is not None:
            sections[current]["lines"].append(line)
    return meta, body, sections


def cells(line):
    return [v.strip().replace(r"\|", "|") for v in re.split(r"(?<!\\)\|", line.strip().strip("|"))]


def table_rows(text):
    """Read ID-keyed pipe tables, preserving actual header names."""
    header, active = None, False
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            header, active = None, False
            continue
        parts = cells(line)
        if all(re.fullmatch(r":?-{3,}:?", x) for x in parts):
            active = bool(header and header[0] == "ID")
            continue
        if not active:
            header = parts
        elif parts and ID_ANY_RE.fullmatch(parts[0]):
            if not re.fullmatch(ID_RE, parts[0]):
                raise ValueError(f"非法 ID {parts[0]}，编号至少三位数字")
            if len(parts) != len(header):
                raise ValueError(f"{parts[0]} 表格列数错误；竖线需写为 \\|")
            yield dict(zip(header, parts))


def pipe_rows(text, first_header):
    """读任意以 first_header 为首列的粗管表；不做 ID 格式校验。"""
    header, active = None, False
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            header, active = None, False
            continue
        parts = cells(line)
        if all(re.fullmatch(r":?-{3,}:?", x) for x in parts):
            active = bool(header and header[0] == first_header)
            continue
        if not active:
            header = parts
        elif parts:
            yield dict(zip(header, parts))


def table_data_rows(text):
    """数一个片段里所有粗管表的数据行（去掉表头行与分隔行）。

    用于「这一节到底有没有记录」的判断：表头还在、数据行一条没有 = 空表。
    """
    rows, header = [], None
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            header = None
            continue
        parts = cells(line)
        if all(re.fullmatch(r":?-{3,}:?", x) for x in parts):
            continue
        if header is None:
            header = parts
            continue
        rows.append(parts)
    return rows


def narrative_length(text):
    """统计叙述性正文的字数：剔除空白、Markdown 标记与代码块后计字符数。

    中文语境里的「500–1000 字」按字符数近似：汉字与中文标点计入，
    Markdown 符号（# > | * ` ~ _）与空白不计入。
    """
    body = re.sub(r"```.*?```", "", text, flags=re.S)
    body = re.sub(r"[#>*|`~*_]", "", body)
    return len(re.sub(r"\s+", "", body))


def ai_tone_hits(text):
    """找出 AI 腔 / 黑话词。风格问题只给警告，不拦截交付。"""
    return sorted({w for w in AI_TONE if w in text})


def intro_version_anchor(text):
    """取人类摘要头部的 PRD 版本锚点。

    形如：> 对应 PRD：PRD.md（0.1.0）
    扫到第一个「## 」小节之前为止——正文里也可能出现版本字样，
    不能全文乱扫；但也不能只认前几行，用户在标题后多写两行导语就会漏掉锚点。
    返回 (版本号 or None, 命中的原文 or None, 命中所在行号 or None)；
    版本号写成了非 x.y.z 时版本号为 None，但原文与行号照给——好让报错说清是「格式不对」
    还是「压根没写」。
    """
    head = []
    for index, line in enumerate(text.splitlines()):
        if line.startswith("## "):
            break
        head.append((index, line))
    blob = "\n".join(line for _, line in head)

    def line_of(fragment):
        for index, line in head:
            if fragment in line:
                return index
        return None

    m = ANCHOR_RE.search(blob)
    if m:
        value = m.group(1).strip()
        return (value if re.fullmatch(r"\d+\.\d+\.\d+", value) else None), m.group(0), line_of(m.group(0))
    hit = re.search(r"PRD[：:]\s*PRD\.md", blob)
    return None, (hit.group(0) if hit else None), (line_of(hit.group(0)) if hit else None)


def intro_body_lines(text, anchor_line=None):
    """取出人类摘要的正文行。

    去掉三类非正文：标题行、**版本锚点那一行**、模板指引块。
    **不能把所有提到「PRD：PRD.md」的行都丢掉**——正文里「详见 PRD：PRD.md 第 3 节」
    是在写内容，整行丢掉会漏检占位词、少算篇幅；只排除锚点所在的那一行。
    也不能把所有引用块都丢掉——正文用引用块写是合法的，全丢会误判成「空文档」；
    只排除「含指引标记的那一块」就够。
    """
    lines = text.splitlines()
    guide = set()
    for i, line in enumerate(lines):
        if INTRO_GUIDE in line:
            j = i
            while j >= 0 and lines[j].lstrip().startswith(">"):
                guide.add(j)
                j -= 1
            j = i
            while j < len(lines) and lines[j].lstrip().startswith(">"):
                guide.add(j)
                j += 1
            break
    body = []
    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        if i in guide:
            continue
        if anchor_line is not None and i == anchor_line:
            continue
        body.append(line)
    return "\n".join(body)


def intro_section_titles(text):
    """取出小节标题与其主名。

    主名 = 标题里冒号前的那段（「背景：为什么现在做」→ 背景），
    这样带说明的小标题也算数，不必一字不差地照抄四个名字。
    代码块里的假标题不算（先 unfenced 去掉代码块）。
    """
    titles = []
    for line in unfenced(text).splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            title = m.group(1).strip()
            titles.append((title, re.split(r"[：:]", title)[0].strip()))
    return titles


def intro_section_bodies(text):
    """按小标题切出各节正文。代码块里的假标题不算（先 unfenced 去掉代码块）。"""
    flat = unfenced(text).splitlines()
    marks = []
    for i, line in enumerate(flat):
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            marks.append((i, re.split(r"[：:]", m.group(1).strip())[0].strip()))
    bodies = {}
    for index, (start, name) in enumerate(marks):
        end = marks[index + 1][0] if index + 1 < len(marks) else len(flat)
        bodies.setdefault(name, "\n".join(flat[start + 1:end]))
    return bodies


def check_intro(intro_path, meta, definitions, errors, warnings, gate):
    """核对项目简介：写给外行看的那一篇。

    与 PRD 的关系是「同一件事的两面」——简介讲人话，PRD 写规则，所以两边不能各说各话：
    简介引用的 ID 必须在 PRD 里真实存在，头部版本锚点必须跟 PRD 当前版本一致。
    """
    hard = hard_gate(gate)

    def flag(msg):
        (errors if hard else warnings).append(msg)

    path = Path(intro_path)
    if not path.is_file():
        flag(f"{INTRO_FILE} 不存在：项目简介是给不熟悉本项目的人看的说明，必须与 PRD 同时存在")
        return
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        errors.append(f"{INTRO_FILE} 读取失败：{exc}")
        return
    anchor, raw, anchor_line = intro_version_anchor(text)
    body = intro_body_lines(text, anchor_line)
    if not body.strip():
        errors.append(f"{INTRO_FILE} 为空")
        return
    hits = sorted(set(INTRO_PLACEHOLDER.findall(body)))
    if hits:
        flag(f"{INTRO_FILE} 存在占位/未确认内容：" + "、".join(hits[:5]))
    # 四件事各占一节：读者能一眼扫到「为什么做 / 哪里难受 / 打算怎么做 / 做完变好在哪」。
    titles = intro_section_titles(text)
    keys = [key for _, key in titles]
    heads = set(keys)
    missing = [name for name in INTRO_SECTIONS if name not in heads]
    if missing:
        flag(f"{INTRO_FILE} 缺少小节：" + "、".join(missing)
             + "（应分「" + " / ".join(INTRO_SECTIONS) + "」四节叙述）")
    dup = sorted({k for k in keys if keys.count(k) > 1})
    if dup:
        warnings.append(f"{INTRO_FILE} 有重复的小节标题：" + "、".join(dup))
    sections = intro_section_bodies(text)
    for name in INTRO_SECTIONS:
        if name in sections and not sections[name].strip():
            warnings.append(f"{INTRO_FILE} 的「{name}」节只有标题、没有内容")
    size = narrative_length(body)
    if size < INTRO_MIN:
        warnings.append(f"{INTRO_FILE} 偏短（约 {size} 字）：给人看的叙述建议 {INTRO_MIN}–{INTRO_MAX} 字")
    elif size > INTRO_MAX:
        warnings.append(f"{INTRO_FILE} 偏长（约 {size} 字）：给人看的叙述建议 {INTRO_MIN}–{INTRO_MAX} 字")
    if table_data_rows(text):
        warnings.append(f"{INTRO_FILE} 要写成给人读的连续叙述，不要用表格罗列")
    if INTRO_GUIDE in text:
        warnings.append(f"{INTRO_FILE} 还留着模板指引，写完后请删掉")
    if definitions:
        unknown = ids(body, set(ID_PREFIXES)) - set(definitions)
        if unknown:
            flag(f"{INTRO_FILE} 引用了 PRD 中不存在的 ID：" + ", ".join(sorted(unknown)))
    shorts = sorted(set(SHORT_ID_RE.findall(body)))
    if shorts:
        flag(f"{INTRO_FILE} 里的 ID 编号不足三位（至少三位）：" + "、".join(shorts))
    if anchor is None:
        if raw:
            flag(f"{INTRO_FILE} 的版本锚点格式不对：{raw}（应写「对应 PRD：PRD.md（x.y.z）」）")
        else:
            flag(f"{INTRO_FILE} 未声明已对齐的 PRD 版本（应写「对应 PRD：PRD.md（x.y.z）」）")
    elif anchor != str(meta.get("version")):
        flag(f"{INTRO_FILE} 的 PRD 版本与 PRD frontmatter version 不一致："
             f"简介 {anchor} vs PRD {meta.get('version')}")
    tone = ai_tone_hits(body)
    if tone:
        warnings.append(f"{INTRO_FILE} 出现 AI 腔/黑话词（改成具体的人和事）：" + "、".join(tone))


def check_summary(summary_path, meta, definitions, errors, warnings, gate):
    """核对已有项目增量的一页决策摘要。"""
    hard = hard_gate(gate)

    def flag(msg):
        (errors if hard else warnings).append(msg)

    path = Path(summary_path)
    if not path.is_file():
        flag(f"{SUMMARY_FILE} 不存在：已有项目增量必须有一页决策摘要")
        return
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        errors.append(f"{SUMMARY_FILE} 读取失败：{exc}")
        return
    anchor, raw, anchor_line = intro_version_anchor(text)
    body = intro_body_lines(text, anchor_line)
    if not body.strip():
        errors.append(f"{SUMMARY_FILE} 为空")
        return
    hits = sorted(set(INTRO_PLACEHOLDER.findall(body)))
    if hits:
        flag(f"{SUMMARY_FILE} 存在占位/未确认内容：" + "、".join(hits[:5]))
    titles = intro_section_titles(text)
    keys = [key for _, key in titles]
    missing = [name for name in SUMMARY_SECTIONS if name not in set(keys)]
    if missing:
        flag(f"{SUMMARY_FILE} 缺少小节：" + "、".join(missing)
             + "（应分「" + " / ".join(SUMMARY_SECTIONS) + "」五节）")
    dup = sorted({k for k in keys if keys.count(k) > 1})
    if dup:
        warnings.append(f"{SUMMARY_FILE} 有重复的小节标题：" + "、".join(dup))
    sections = intro_section_bodies(text)
    for name in SUMMARY_SECTIONS:
        if name in sections and not sections[name].strip():
            warnings.append(f"{SUMMARY_FILE} 的「{name}」节只有标题、没有内容")
    if table_data_rows(text):
        flag(f"{SUMMARY_FILE} 不要用表格罗列：一页决策摘要应写成连贯短段")
    found_ids = ids(body)
    if found_ids:
        flag(f"{SUMMARY_FILE} 不应出现内部 ID：" + "、".join(sorted(found_ids)))
    unknown = found_ids - set(definitions)
    if unknown:
        flag(f"{SUMMARY_FILE} 引用了 PRD 中不存在的 ID：" + "、".join(sorted(unknown)))
    size = narrative_length(body)
    if size < SUMMARY_MIN:
        warnings.append(f"{SUMMARY_FILE} 偏短（约 {size} 字）：建议 {SUMMARY_MIN}–{SUMMARY_MAX} 字")
    elif size > SUMMARY_MAX:
        warnings.append(f"{SUMMARY_FILE} 偏长（约 {size} 字）：一页摘要建议不超过 {SUMMARY_MAX} 字")
    if anchor is None:
        if raw:
            flag(f"{SUMMARY_FILE} 的版本锚点格式不对：{raw}")
        else:
            flag(f"{SUMMARY_FILE} 未声明已对齐的 PRD 版本（应写「对应 PRD：PRD.md（x.y.z）」）")
    elif anchor != str(meta.get("version")):
        flag(f"{SUMMARY_FILE} 的 PRD 版本与 PRD frontmatter version 不一致："
             f"摘要 {anchor} vs PRD {meta.get('version')}")
    tone = ai_tone_hits(body)
    if tone:
        warnings.append(f"{SUMMARY_FILE} 出现 AI 腔/黑话词（改成具体的人和事）：" + "、".join(tone))


def report():
    return {"ok": False, "errors": [], "warnings": []}


def conclusion_sections(text):
    """把拷问结论按二级标题切成 {标题: [行]}；保持文件出现顺序。"""
    sections, order, current = {}, [], None
    for line in text.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            current = m.group(1).strip()
            order.append(current)
            sections.setdefault(current, [])
            continue
        if current is not None:
            sections[current].append(line)
    return sections, order


def conclusion_items(lines):
    """把一节切成条目：每个 `1. ` / `- ` 开头且带粗体标题的行起一条。

    返回 (items, orphan)：items 是 [{title, fields:{名:值}}]，
    orphan 是既不是条目也不是空行的行（例如条目下的续行），用来判断这一节
    到底是「无」还是「写了一堆但不是条目」。
    """
    items, orphan, current = [], [], None
    for raw in lines:
        line = raw.rstrip()
        if not line.strip():
            continue
        head = re.match(r"^\s*(?:\d+[.、)]|[-*])\s+(.*)$", line)
        bold = re.search(r"\*\*(.+?)\*\*", head.group(1)) if head else None
        if bold:
            current = {"title": bold.group(1).strip(), "fields": {}}
            items.append(current)
            continue
        field = re.match(r"^\s*[-*]\s*([^：:]{1,14})[：:]\s*(.*)$", line)
        if field and current is not None:
            current["fields"][field.group(1).strip()] = field.group(2).strip()
            continue
        orphan.append(line)
    return items, orphan


def section_is_deliberately_empty(lines):
    body = "\n".join(line for line in lines if line.strip())
    return bool(body) and bool(CONCLUSION_NONE_RE.match(body))


def check_conclusion(path, gate="draft"):
    """校验拷问结论的结构与必备字段。

    这是 prd-doc 第 0 步的出口门，也是成文之前的那道检查。
    它只判「有没有把话说清」的形式：四分类在不在、每条有没有写依据/默认值/下一步。
    判断「这个决策对不对」「确认是否真的发生过」不是脚本能做的。
    """
    result = report()
    errors, warnings = result["errors"], result["warnings"]
    hard = hard_gate(gate)
    target = Path(path)
    if not target.is_file():
        errors.append(f"拷问结论不存在：{path}")
        result.update(ok=False, gate=gate, file=str(target), counts={})
        return result
    text = target.read_text(encoding="utf-8-sig")

    if not re.search(r"(?m)^#\s+\S", text):
        errors.append("缺少一级标题（# <标题> 拷问结论）")

    # 头部元信息
    mode = CONCLUSION_MODE_RE.search(text)
    if not mode:
        errors.append("头部缺少 doc_mode（新建 / 增量）：下游 prd-doc 靠它决定写哪份摘要")
    day = CONCLUSION_DATE_RE.search(text)
    if not day:
        (errors if hard else warnings).append("头部缺少日期（> 日期：YYYY-MM-DD）")
    elif not valid_date(day.group(1)):
        errors.append(f"头部日期不是合法 ISO 日期：{day.group(1)}")
    rounds = CONCLUSION_ROUND_RE.search(text)
    frontier = CONCLUSION_FRONTIER_RE.search(text)
    if not rounds:
        (errors if hard else warnings).append("头部缺少轮次（> 轮次：N）")
    if not frontier:
        (errors if hard else warnings).append("头部缺少前沿状态（> 前沿：已空）")
    elif frontier.group(1) not in ("已空", "为空", "空"):
        (errors if hard else warnings).append(
            f"前沿未空（{frontier.group(1)}）：设计树还有没走到的分支，问完再落盘")
    if not CONCLUSION_META_RE.search(text):
        (errors if hard else warnings).append("头部缺少元信息行（> 日期 ｜ 轮次 ｜ 前沿 ｜ doc_mode）")

    sections, order = conclusion_sections(text)
    counts = {}
    for name in CONCLUSION_SECTIONS:
        if name not in sections:
            errors.append(f"缺少分类「{name}」（四类必须齐全，没有内容就写「无。」）")
            continue
        lines = sections[name]
        items, orphan = conclusion_items(lines)
        counts[name] = len(items)
        if not items:
            if section_is_deliberately_empty(lines) or not "".join(lines).strip():
                if not "".join(lines).strip():
                    errors.append(f"「{name}」是空节：没有就写「无。」并说明为什么，不要留白")
                continue
            errors.append(f"「{name}」里没有条目：每条以 `1. **一句话**` 开头，"
                          "字段用 `   - 名称：值` 缩进写在条目下面")
            continue
        for index, item in enumerate(items, start=1):
            label = f"「{name}」第 {index} 条（{item['title']}）"
            for field in CONCLUSION_FIELDS[name]:
                if field not in item["fields"]:
                    errors.append(f"{label} 缺少字段「{field}」")
                elif not item["fields"][field]:
                    errors.append(f"{label} 的「{field}」是空的")
            if name == "未解决的问题":
                blocked = item["fields"].get("阻塞", "").strip()
                if blocked and blocked not in ("是", "否"):
                    errors.append(f"{label} 的「阻塞」只能写 是 / 否，实际写的是「{blocked}」")
                elif blocked == "是":
                    warnings.append(
                        f"{label} 标了阻塞：prd-doc 会把它写成 问题-xxx，"
                        "而 PRD 定稿档要求阻塞问题清零——交付前得解决或明确移出范围")

    extra = [name for name in order if name not in CONCLUSION_SECTIONS]
    if extra:
        warnings.append("出现了四分类之外的二级标题（不属于契约，下游会忽略）："
                        + "、".join(extra))
    present = [n for n in order if n in CONCLUSION_SECTIONS]
    if present != [n for n in CONCLUSION_SECTIONS if n in present]:
        warnings.append("四分类顺序与契约不一致：建议按 已定决策 → 采纳的假设 → "
                        "未解决的问题 → 被驳的推荐 排列")

    body = "\n".join(line for line in text.splitlines() if not line.lstrip().startswith(">"))
    placeholders = PLACEHOLDER.findall(body)
    if placeholders:
        (errors if hard else warnings).append(
            "存在占位/未确认内容：" + ", ".join(sorted(set(placeholders))))
    tone = ai_tone_hits(body)
    if tone:
        warnings.append("出现 AI 腔/黑话词（结论也要人看得懂）：" + "、".join(tone))

    result.update(
        ok=not errors,
        gate=gate,
        file=str(target),
        doc_mode=mode.group(1) if mode else None,
        frontier=frontier.group(1) if frontier else None,
        rounds=int(rounds.group(1)) if rounds else None,
        counts=counts,
        not_checked=[
            "决策是否合理、取舍是否值得",
            "四分类归位是否准确（脚本只看结构，不看内容归属）",
            "用户是否真的确认过这份共识",
            "前沿是否真的为空（脚本只读头部声明）",
        ],
    )
    return result


def valid_date(value):
    try:
        date.fromisoformat(str(value))
        return True
    except (ValueError, TypeError):
        return False


def version_rows(section_text):
    """解析第 12 节（增量第 6 节）「版本记录」子表；返回数据行列表或 None（缺子表）。"""
    m = re.search(r"^###\s*版本记录\s*$", section_text, re.M)
    if not m:
        return None
    rest = section_text[m.end():]
    nxt = re.search(r"^###\s+", rest, re.M)
    if nxt:
        rest = rest[:nxt.start()]
    rows = []
    for line in rest.splitlines():
        if not line.strip().startswith("|"):
            continue
        parts = cells(line)
        if all(re.fullmatch(r":?-{3,}:?", x) for x in parts):
            continue
        if parts[0] == "版本":
            continue
        rows.append(parts)
    return rows


def check_version_records(meta, sections, definitions, errors, warnings, gate, version_section=12):
    hard = hard_gate(gate)
    rows = version_rows("\n".join(sections.get(version_section, {}).get("lines", [])))
    if rows is None:
        errors.append(f"第 {version_section} 节缺少「### 版本记录」子表")
        return
    if not rows:
        errors.append("版本记录表为空")
        return
    seen = set()
    for parts in rows:
        if len(parts) != 5:
            errors.append("版本记录行必须为 5 列：版本/日期/类型/核心修改内容/关联决策")
            continue
        item, day, kind, summary, decision = parts
        if not re.fullmatch(r"\d+\.\d+\.\d+", item):
            errors.append(f"版本号非法：{item}")
        if item in seen:
            errors.append(f"版本记录重复：{item}")
        seen.add(item)
        if not valid_date(day):
            errors.append(f"{item} 日期非法：{day}")
        if kind not in CHANGE_TYPES:
            errors.append(f"{item} 类型必须为 {'/'.join(CHANGE_TYPES)}：{kind}")
        if not summary or summary == "-":
            errors.append(f"{item} 缺少核心修改内容")
        # 契约要求核心修改内容点明受影响的 ID，不写不指向具体改动的空话
        if not ids(summary):
            (errors if hard else warnings).append(f"{item} 核心修改内容必须点明受影响的 ID")
        for phrase in FORBIDDEN_VAGUE:
            if phrase in summary:
                (errors if hard else warnings).append(
                    f"{item} 核心修改内容含空话「{phrase}」，需改写为具体改动")
        for dec in ids(decision, {"决策"}):
            if dec not in definitions:
                errors.append(f"{item} 引用不存在的决策 {dec}")
    valid = [p for p in rows if len(p) == 5]
    seq = [p[0] for p in valid if re.fullmatch(r"\d+\.\d+\.\d+", p[0])]
    parsed = [tuple(int(x) for x in v.split(".")) for v in seq]
    # 版本记录表是唯一变更历史，行只追加：版本号必须递增
    if any(b <= a for a, b in zip(parsed, parsed[1:])):
        errors.append("版本记录未按时间顺序递增：" + " → ".join(seq))
    if valid:
        latest = valid[-1][0]
        if latest != str(meta.get("version")):
            errors.append(f"frontmatter version 与版本记录最后一行不一致：{meta.get('version')} vs {latest}")
        if meta.get("status") in PRD_STATUS[2:] and not ids(valid[-1][4], {"决策"}):
            errors.append(f"{PRD_STATUS[2]}版本 {latest} 的版本记录缺少决策（决策-xxx）确认证据")


def prototype_files(directory):
    """原型文件清单：入口 `prototype.html` 在前，拆分的页面文件按名排序跟在后面。

    多文件原型的命名约定是 `prototype.<页面slug>.html`；有页面文件时，
    入口 `prototype.html` 就是索引页。单文件模式下只返回一个 `prototype.html`，
    与 v1.6.0 的行为完全一致。
    """
    directory = Path(directory)
    files = []
    entry = directory / "prototype.html"
    if entry.is_file():
        files.append(entry)
    files.extend(sorted(directory.glob("prototype.*.html")))
    return files


def is_draft(html):
    """草案原型：根节点写 `data-prd-id="draft"`，不带 `data-prd-version`。

    草案是「先画原型、后写 PRD」那条路的中间态：PRD 还不存在或还没过门，
    所以既不该被标记闭合管，也不该拿它去过 ready 门。PRD 过门后它必须转正。
    """
    return 'data-prd-id="draft"' in str(html or "")


def is_page_link(target):
    """同目录的 .html 相对链接是页面间跳转，不算「外部资源」。

    多文件原型的索引页必然要链到各页面文件，把这些链接判成「引用了外部资源」
    会让合法的多文件原型永远过不了门。判据只看形态：不含协议、不以 / 开头、
    去掉 #hash 与 ?query 后以 .html 结尾。
    """
    target = str(target or "").strip()
    if not target or "://" in target or target.startswith("//") or target.startswith("/"):
        return False
    path = target.split("#", 1)[0].split("?", 1)[0]
    return path.lower().endswith(".html")


PAGE_ID_RE = re.compile(r'data-page-id="([^"]*)"')


def section_body(prd_path, meta, prefix):
    """取某个 ID 前缀所属章节的正文（页面声明就从「页面」那节读）。"""
    _, _, sections = load_doc(prd_path)
    number = prefixes_for(meta).get(prefix)
    if not number:
        return ""
    return "\n".join(sections.get(number, {}).get("lines", []))


def check_prototype(meta, prd_path, definitions, errors, warnings, gate):
    """核对原型：标记闭合（谁被实现）+ 高保真底线（能不能真的打开操作）。

    标记闭合只认源码里的字面量，是「文本里有」；高保真底线是「双击能跑、能点」。
    两者都不能证明界面真的走通了——那要实机操作，见 prd-prototype 的证据分级。

    2.0.0 起原型可以是多文件：入口 `prototype.html`（有页面文件时即索引页）
    + `prototype.<slug>.html` 页面文件。标记闭合跨文件聚合——一条需求标在哪个
    文件里都算覆盖；页面文件用 `data-page-id` 声明自己画的是哪个页面，与 PRD
    第 5 节声明的页面集合双向对齐。草案（`data-prd-id="draft"`）不进门禁。
    """
    hard = hard_gate(gate)

    def flag(msg):
        (errors if hard else warnings).append(msg)

    prototype = meta.get("prototype")
    directory = Path(prd_path).parent
    files = prototype_files(directory)
    if prototype in (None, ""):
        if files:
            (errors if hard else warnings).append(
                "prototype 为 null 但同目录仍有原型文件（"
                + "、".join(p.name for p in files[:5]) + "）；取消原型须同时删除文件")
        return
    if not str(prototype).endswith(".html"):
        errors.append("prototype 必须指向 .html 文件")
        return
    entry = directory / str(prototype)
    if not entry.is_file():
        (errors if hard else warnings).append(f"原型文件不存在：{prototype}")
        return
    if not any(p.name == entry.name for p in files):
        files = [entry] + files

    texts = {p.name: p.read_text(encoding="utf-8-sig") for p in files}
    page_files = [p for p in files if p.name != entry.name]
    index_is_entry = bool(page_files)

    # ---- 草案：入口是草案就整份按草案处理，只留一条「未转正」提醒 ----
    if is_draft(texts.get(entry.name, "")):
        warnings.append(
            "原型仍是草案（data-prd-id=\"draft\"），未转正：反向识别确认、PRD 过 "
            "`check --gate ready` 之后，要补 data-* 标记与 data-prd-version 并重跑 check"
            "——草案不是终点")
        return

    for path in files:
        html = texts[path.name]
        label = "" if path.name == entry.name else f"（{path.name}）"
        if is_draft(html):
            (errors if hard else warnings).append(
                f"原型页面文件 {path.name} 仍是草案（data-prd-id=\"draft\"），与入口状态不一致："
                "要么一起转正，要么整份都留在草案态")
            continue
        if f'data-prd-id="{meta.get("prd_id")}"' not in html:
            (errors if hard else warnings).append(
                f"原型根节点 data-prd-id 与 PRD 不一致{label}")
        if f'data-prd-version="{meta.get("version")}"' not in html:
            (errors if hard else warnings).append(
                f"原型根节点 data-prd-version 与 PRD 版本不一致{label}")
        if not re.search(r"<html[^>]+lang=", html, re.I):
            warnings.append(f"原型 <html> 未声明 lang（中文界面应写 lang=\"zh-CN\"）{label}")

    # ---- 高保真底线：只判机械可判的部分 ----
    # 索引页是纯链接导航页：它本来就没有交互事件、样式规则也少，拿这两项去判它，
    # 只会让合法的多文件原型过不了门。viewport 仍然要——索引页也要能在窄屏打开。
    for path in files:
        html = texts[path.name]
        if is_draft(html):
            continue
        suffix = f"（{path.name}）" if path.name != entry.name else ""
        if not re.search(r"<meta[^>]+name=[\"']viewport[\"']", html, re.I):
            flag("原型缺少 <meta name=\"viewport\">：窄屏视口无法按预期适配" + suffix)
        if index_is_entry and path.name == entry.name:
            continue
        style_body = inline_block(html, STYLE_OPEN_RE, STYLE_CLOSE_RE)
        if style_body is None:
            flag("原型没有内联 <style>：保真要求视觉是有意设计的，不是浏览器默认渲染")
        elif len(re.findall(r"\{[^{}]*\}", style_body)) < MIN_STYLE_RULES:
            flag(f"原型的样式规则过少（< {MIN_STYLE_RULES} 条）：看起来只搭了骨架，没有做视觉设计")
        script_body = inline_block(html, SCRIPT_OPEN_RE, SCRIPT_CLOSE_RE)
        if script_body is None:
            flag("原型没有内联 <script>：高保真原型必须是可交互的，不是静态截图")
        else:
            # 注释里的 addEventListener 不算交互——它根本不执行。
            live = JS_COMMENT_RE.sub("", script_body)
            if not DRIVE_EVENT_RE.search(live):
                flag("原型没有绑定任何交互事件（addEventListener / onclick 等）：页面点不动")
        external = sorted({m.group(1).strip() for m in EXTERNAL_RESOURCE.finditer(html)
                           if not is_page_link(m.group(1))})
        if external:
            flag("原型引用了外部资源（单文件规则要求全部内联）：" + "、".join(external[:5]))

    # ---- 页面 ↔ 页面文件对齐（只在多文件时判）----
    if page_files:
        declared = ids(section_body(prd_path, meta, "页面"), {"页面"})
        covered = {}
        for path in page_files:
            html = texts[path.name]
            if is_draft(html):
                continue
            found = PAGE_ID_RE.findall(html)
            if not found:
                flag(f"页面文件 {path.name} 缺少 data-page-id：它在画哪个页面，机器和人都该"
                     "看得出来（写 data-page-id=\"页面-001\"）")
                continue
            for value in found:
                page_ids = ids(value, {"页面"})
                if not page_ids:
                    flag(f"页面文件 {path.name} 的 data-page-id 不是合法页面 ID：「{value.strip()}」")
                    continue
                for page_id in page_ids:
                    if page_id not in declared:
                        flag(f"页面文件 {path.name} 声明了 PRD 里不存在的页面：{page_id}")
                    covered.setdefault(page_id, []).append(path.name)
        missing = sorted(declared - set(covered))
        if missing:
            flag("PRD 声明了页面但没有任何页面文件画它：" + "、".join(missing))

    # ---- 标记闭合 ----
    # data-* 属性名受 HTML 规范约束必须是小写 ASCII，不能用中文；
    # 属性值里的 ID 用中文前缀。
    #
    # 扫描口径（这是闭合校验能不能信的关键）：
    #   · HTML 注释不渲染 → 不计入覆盖。否则注释里写一行标记就能骗过闭合校验。
    #   · JS 字符串字面量会进 DOM → 计入（原型用 JS 渲染元素是正常做法）。
    #   · 运行时才拼出来的 ID（如 data-ac-id="'+id+'"）静态不可知 → 单独报错，
    #     因为它既扫不出具体 ID，也说明作者没把 ID 写成字面量。
    #
    # 三种写法都认：静态属性、dataset 赋值、setAttribute。属性值用单引号也认
    # （HTML 允许单引号，只认双引号会把合法原型误判成缺标记）。
    #
    # 多文件时把所有非草案文件扫出的 ID 并进同一个集合再比对——一条需求标在
    # 列表页还是详情页，都是「被实现了」，不该按文件切片判。
    html_ids = {"需求": set(), "交互": set(), "验收": set()}
    non_literal = []
    attr_map = {"req": "需求", "int": "交互", "ac": "验收"}
    # 双引号与单引号分成两套模式，不能混在一个字符类里：
    # 混写时 data-ac-id="'+id+'" 会被解析成空值（开引号 "、空内容、闭引号 '），
    # 非字面量的标记就检测不出来了。
    dq = r'"([^"]*)"'
    sq = r"'([^']*)'"
    patterns = [
        re.compile(r'data-(req|int|ac)-id=' + dq),
        re.compile(r"data-(req|int|ac)-id=" + sq),
        re.compile(r'dataset\.(req|int|ac)Id\s*=\s*' + dq),
        re.compile(r"dataset\.(req|int|ac)Id\s*=\s*" + sq),
        re.compile(r'setAttribute\(\s*"data-(req|int|ac)-id"\s*,\s*' + dq),
        re.compile(r"setAttribute\(\s*'data-(req|int|ac)-id'\s*,\s*" + sq),
    ]
    for path in files:
        html = texts[path.name]
        if is_draft(html):
            continue
        scan = HTML_COMMENT_RE.sub("", html)
        for pattern in patterns:
            for m in pattern.finditer(scan):
                kind = attr_map[m.group(1)]
                value = m.group(2)
                found = ids(value)
                if not found and value.strip():
                    non_literal.append((kind, value.strip()))
                html_ids[kind].update(found)
    for kind, raw in non_literal[:5]:
        (errors if hard else warnings).append(
            f"原型标记值不是字面量 ID（{kind}：「{raw}」）：运行时拼接的标记无法被静态校验，"
            "请把 ID 直接写成字面量")
    for kind in ("需求", "交互", "验收"):
        defined = {k for k in definitions if k.startswith(kind + "-")}
        missing = defined - html_ids[kind]
        unknown = html_ids[kind] - defined
        if missing:
            (errors if hard else warnings).append(f"原型缺少 {kind} 标记：" + ", ".join(sorted(missing)))
        if unknown:
            (errors if hard else warnings).append(f"原型标记了不存在的 {kind}：" + ", ".join(sorted(unknown)))


def wants_empty_claim_rule(meta):
    """1.6.0：没有材料就陈述事实，别留空、别写「待确认」、别为了填满而编。

    这条规则是一次**减法**，减掉三种假东西：留白（读者分不清是没有还是漏了）、
    「待确认」（那是「还没写」，不是「没有」）、以及为了填满格子现编的竞品分析。
    正经的空缺只有两种，都必须带原因：`未提供：…`（该有，这次没有材料）、
    `不适用：…`（本产品根本不涉及）。
    """
    return schema_at_least(meta, "1.6.0")


def summary_rows(section_lines):
    """读一页摘要的两列表，返回 {行名: 值}。只认「| 行名 | 值 |」这种两列写法。"""
    found, header_seen = {}, False
    for line in section_lines:
        if not line.strip().startswith("|"):
            continue
        row = cells(line)
        if all(re.fullmatch(r":?-{3,}:?", x) for x in row):
            header_seen = True
            continue
        if len(row) < 2 or row[0] in ("项目", "项"):
            continue
        found.setdefault(row[0], row[1])
    return found if header_seen or found else {}


def _claim_in_value(value):
    """一个表格单元格 / 一行正文里，是否以空值陈述开头。返回 [(词, 原因, 原文)]。

    只认「整个格子 / 整行开头」这一种位置。判据这么定的原因：PRD 里到处都有
    「没有界面就写『不适用：原因』」这类**讲规则**的句子，那些不是空值陈述本身；
    真正的空值陈述只会占满一个格子或起头一整行。
    """
    text = str(value or "").strip()
    match = re.match(r"^(未提供|不适用)\s*([：:]?)\s*(.*)$", text)
    if not match:
        return []
    word, colon, rest = match.groups()
    rest = rest.strip().rstrip("。；;，,、）」)】")
    return [(word, rest if colon else "", text)]


def empty_claims_in(text):
    """抽出文本里所有空值陈述（表格按格、正文按行，见 `_claim_in_value`）。"""
    claims = []
    for raw_line in str(text or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("|"):
            for value in cells(line):
                claims.extend(_claim_in_value(value))
            continue
        line = re.sub(r"^(?:[-*+]\s+|\d+[.、]\s+|>\s*)", "", line)
        claims.extend(_claim_in_value(line))
    return claims


def check_empty_claims(meta, body, sections, definitions, errors, warnings, gate):
    """1.6.0 的门：空值必须写成「未提供：原因」或「不适用：原因」，核心位置不许空。

    三条判据，都只看字面，不猜意图：
      1. 光秃秃的「未提供 / 不适用」（没有冒号或没有原因）→ 说明它到底是哪一种；
      2. 一页摘要七行不许空；其中「一句话 / 问题 / 用户 / 方案」四行不接受空值陈述
         ——那不是材料不足，是这件事本身还没想清楚，该回去追问；
      3. P0 需求的「要求与边界」与「验收」不允许用空值陈述糊过去。
    返回每一处带原因的空值陈述 `{section, title, claim, reason}`；由调用方决定
    怎么呈现——只有「未提供」进 gaps（缺口），「不适用」只计数。
    """
    hard = hard_gate(gate)

    def flag(message):
        (errors if hard else warnings).append(message)

    claims = []
    for number, section in sorted(sections.items()):
        if number <= 0:
            # 第 0 号是「一页摘要」这类不编号的开头小节，下面单独判，避免重复报。
            continue
        section_text = "\n".join(section["lines"])
        for word, reason, raw in empty_claims_in(section_text):
            if not reason or len(reason) < EMPTY_CLAIM_MIN_REASON:
                flag(f"第 {number} 节的「{raw}」没写原因：写成「{word}：原因」"
                     "（该有但这次没有材料写「未提供」；本产品不涉及写「不适用」）")
                continue
            claims.append({
                "section": number,
                "title": section["title"],
                "claim": word,
                "reason": reason,
            })

    summary_lines = []
    for line in body.splitlines():
        summary_lines.append(line)
    intro_index = next((i for i, line in enumerate(summary_lines)
                        if line.strip().startswith("## ") and "一页摘要" in line), None)
    if intro_index is not None:
        block = []
        for line in summary_lines[intro_index + 1:]:
            if line.strip().startswith("## "):
                break
            block.append(line)
        rows = summary_rows(block)
        for name in SUMMARY_ROWS:
            if name not in rows:
                warnings.append(f"一页摘要缺「{name}」行：七行是读者三十秒看懂这份文档的唯一入口")
                continue
            value = (rows.get(name) or "").strip()
            if not value:
                flag(f"一页摘要的「{name}」是空的：没有材料就写「未提供：原因」，不要留白")
                continue
            hits = empty_claims_in(value)
            if not hits:
                continue
            word, reason, raw = hits[0]
            if name in SUMMARY_CORE_ROWS:
                flag(f"一页摘要的「{name}」写了「{raw}」：这四行讲的是产品本身，"
                     "缺它说明这件事还没定，不是材料不足——先回去问清楚，别用空值陈述顶过去")
            elif not reason or len(reason) < EMPTY_CLAIM_MIN_REASON:
                flag(f"一页摘要的「{name}」写了「{raw}」没写原因：写成「{word}：原因」")
            else:
                claims.append({"section": 0, "title": "一页摘要", "claim": word, "reason": reason})

    for req_id, row in sorted(definitions.items()):
        if not req_id.startswith("需求-"):
            continue
        priority = str(row.get("优先级") or "").strip().upper()
        if priority != "P0":
            continue
        for field in ("要求与边界", "验收"):
            value = str(row.get(field) or "")
            hits = empty_claims_in(value)
            if hits:
                flag(f"{req_id} 是 P0，但「{field}」写的是「{hits[0][2]}」："
                     "P0 需求不允许用空值陈述，先补齐再定稿")
    return claims


def check_prd(path, gate="draft"):
    result = report()
    errors, warnings = result["errors"], result["warnings"]
    meta, body, sections = load_doc(path)
    # 正文里出现的图片文件名（旧文档残留的指针行、或用户顺手贴的路径）不是 PRD 内部 ID：
    # 形如 `交互-001-frames.png` 的记号若不剔掉，扫未知引用时会被当成多出来的记号。
    body_for_ids = re.sub(r"[^\s|`]*\.png", " ", body)
    for key in REQUIRED_META:
        if key not in meta or meta.get(key) == "":
            errors.append(f"缺少元数据 {key}")
    if str(meta.get("schema_version")) not in SCHEMA_VERSIONS:
        errors.append("不支持的 schema_version，本工具只接受 v1.0.0 / v1.6.0（当前）"
                      "/ v1.1.0、v1.2.0、v1.3.0、v1.4.0（旧号）"
                      "（旧版必须重构或显式迁移）")
    if meta.get("doc_mode") not in (None, "") and str(meta.get("doc_mode")) not in DOC_MODES:
        errors.append("非法 doc_mode：" + "/".join(DOC_MODES))
    if "delivery" in meta:
        errors.append("v1.0 已取消 delivery 字段：开工包这一交付形态不在本套件内，请删除该键")
    if meta.get("prd_id") and not re.fullmatch(SLUG_RE, str(meta.get("prd_id"))):
        errors.append("prd_id 仅允许小写字母、数字和连字符")
    if not re.fullmatch(r"\d+\.\d+\.\d+", str(meta.get("version", ""))):
        errors.append("version 必须为 x.y.z")
    if meta.get("status") not in PRD_STATUS:
        errors.append("非法 PRD 状态：" + "/".join(PRD_STATUS))
    if not valid_date(meta.get("updated_at")):
        errors.append("updated_at 必须为 ISO 日期")
    if meta.get("prototype") not in (None, "") and not str(meta.get("prototype")).endswith(".html"):
        errors.append("prototype 必须为 .html 路径或 null")
    headings = headings_for(meta, body)
    prefix_map = prefixes_for(meta)
    for number, title in headings.items():
        if number not in sections or sections[number]["title"] != title:
            errors.append(f"缺少规范章节 {number}. {title}")
        elif not "\n".join(sections[number]["lines"]).strip():
            errors.append(f"章节 {number} 为空")

    # 1.1.0 的「可读性」检查只给 warning：格式可以逐步迁移，不因为少了摘要就把人挡在门外。
    if is_unified_contract(meta, body):
        if "## 一页摘要" not in body:
            warnings.append("建议在正文开头加「## 一页摘要」：一句话、问题、用户、方案、成功指标、本期不做、最大风险")
        # 章号跟着契约走：1.3.0 的指标在第 1 节、用户故事在第 5 节；1.4.0 起分别是
        # 第 2 节和第 6 节。写死章号会让新文档永远差一句「建议」（实测撞过）。
        # 增量文档结构不同（没有指标节），这些建议不适用，直接跳过。
        if doc_mode(meta) != "增量":
            goal_section = 2 if schema_at_least(meta, "1.4.0") else 1
            goal_text = "\n".join(sections.get(goal_section, {}).get("lines", []))
            if "成功指标" in goal_text and not re.search(r"\|\s*指标\s*\|", goal_text):
                warnings.append(f"第 {goal_section} 节建议用「指标 | 基线 | 目标 | 观测方式」表写成功指标；"
                                "没有基线数据就写「未提供：没有基线数据」")
            req_section = prefix_map.get("需求")
            req_text = "\n".join(sections.get(req_section, {}).get("lines", []))
            if req_text and "用户故事" not in req_text:
                warnings.append(f"第 {req_section} 节建议先写「用户故事」（作为…我想…以便…），再列需求表")
            risk_section = prefix_map.get("问题")
            risk_text = "\n".join(sections.get(risk_section, {}).get("lines", []))
            if risk_text and "风险" not in risk_text:
                warnings.append(f"第 {risk_section} 节建议补「风险与依赖」：最可能让这件事失败的是什么，谁来兜底")

    definitions, locations = {}, {}
    for number, section in sections.items():
        for row in table_rows("\n".join(section["lines"])):
            item = row["ID"]
            prefix = item.split("-")[0]
            if item in definitions:
                errors.append(f"重复 ID {item}")
            definitions[item], locations[item] = row, number
            if prefix not in prefix_map or number != prefix_map.get(prefix):
                errors.append(f"{item} 定义在错误章节")
            for field in FIELDS.get(prefix, []):
                if not row.get(field):
                    errors.append(f"{item} 缺少字段 {field}")
            if prefix == "验收":
                zh = {f: (row.get(f) or "").strip() for f in ACCEPTANCE_FIELDS_ZH}
                en = {f: (row.get(f) or "").strip() for f in ACCEPTANCE_FIELDS_EN}
                zh_any, en_any = any(zh.values()), any(en.values())
                if zh_any and en_any:
                    errors.append(
                        f"{item} 的验收表混用了中英文列：前提/操作/预期 与 Given/When/Then 二选一")
                elif zh_any:
                    for field, value in zh.items():
                        if not value:
                            errors.append(f"{item} 缺少字段 {field}")
                elif en_any:
                    for field, value in en.items():
                        if not value:
                            errors.append(f"{item} 缺少字段 {field}")
                else:
                    errors.append(
                        f"{item} 缺少验收三列：用「前提 / 操作 / 预期」"
                        "（旧版 Given / When / Then 仍可用）")
            if prefix == "决策" and meta.get("status") in PRD_STATUS[2:]:
                # 已确认版本的决策不能只写一个占位当证据
                evidence = (row.get("确认者与证据") or "").strip()
                if evidence in EVIDENCE_PLACEHOLDER:
                    errors.append(f"{item} 的确认者与证据只是占位（{evidence}），"
                                  "已确认版本必须写实际发生的确认证据")

    int_text = "\n".join(sections.get(prefix_map["交互"], {}).get("lines", []))
    fields = INT_FIELDS
    interactions = list(re.finditer(r"^###\s+(交互-\d{3,})\s+.+$", int_text, re.M))
    # 静默漏判是这里最坏的失败模式：第 6 节确实写了「交互-001 …」的文字，
    # 但既不是 ### 小节、也没有 12 个字段，于是 interactions=0、一个错都不报，
    # 作者以为写完了，直到原型阶段才发现「交互-001 未定义」。实测撞过一次。
    # 判据：章节里出现过 交互-NNN 字样，却一个小节都没解析出来 → 必须报出来。
    if not interactions and re.search(r"交互-\d{3,}", int_text):
        mentioned = sorted(set(re.findall(r"交互-\d{3,}", int_text)))
        (errors if hard_gate(gate) else warnings).append(
            "章节 " + str(prefix_map["交互"]) + " 里出现了 " + "、".join(mentioned[:5]) +
            (" 等" if len(mentioned) > 5 else "") +
            "，但没有一个写成可解析的交互小节：每条交互要以「### 交互-001 标题」开头，"
            "紧跟一张「| 字段 | 内容 |」两列对照表，逐行写满 "
            + "、".join(sorted(fields)) + "。"
            "否则脚本判为 0 条交互，原型阶段才会以「交互-xxx 未定义」暴露")
    parsed_interactions = []
    for index, match in enumerate(interactions):
        item = match.group(1)
        if item in definitions:
            errors.append(f"重复 ID {item}")
        block = int_text[match.end(): interactions[index + 1].start() if index + 1 < len(interactions) else len(int_text)]
        specs = {}
        for line in block.splitlines():
            if line.strip().startswith("|"):
                parts = cells(line)
                if len(parts) == 2 and parts[0] in fields:
                    specs[parts[0]] = parts[1]
        definitions[item] = {"ID": item, **specs}
        parsed_interactions.append({"id": item, "specs": specs})
        for field in sorted(fields):
            if not specs.get(field):
                errors.append(f"{item} 缺少交互字段 {field}")
        if not ids(specs.get("关联需求"), {"需求"}):
            errors.append(f"{item} 必须关联需求 ID")
        if not ids(specs.get("验收"), {"验收"}):
            errors.append(f"{item} 必须关联验收 ID")

    unknown = ids(body_for_ids) - set(definitions)
    if unknown:
        errors.append("未定义引用：" + ", ".join(sorted(unknown)))
    # 编号至少三位：正文写 假设-2 这种两位编号时，ID_RE 的 \d{3,} 抽不到它，
    # 于是它既不算引用也不算未定义，静默消失。单独抓出来报错，否则引用会凭空断掉。
    shorts = sorted(set(SHORT_ID_RE.findall(body_for_ids)))
    if shorts:
        errors.append("ID 编号不足三位（至少三位）：" + "、".join(shorts))
    requirements = {k: v for k, v in definitions.items() if k.startswith(("需求-", "非功能约束-"))}
    acceptance = {k: v for k, v in definitions.items() if k.startswith("验收-")}
    if not any(k.startswith("需求-") for k in requirements):
        (errors if hard_gate(gate) else warnings).append("至少需要一项需求（需求-xxx）")
    if not acceptance:
        (errors if hard_gate(gate) else warnings).append("至少需要一项验收（验收-xxx）")
    for item, row in requirements.items():
        if item.startswith("需求-") and row.get("优先级") not in {"P0", "P1", "P2"}:
            errors.append(f"{item} 优先级必须为 P0/P1/P2")
        if not ids(row.get("来源/决策"), {"来源", "决策"}):
            errors.append(f"{item} 缺少来源/决策引用")
        ac_ids = ids(row.get("验收"), {"验收"})
        if not ac_ids:
            errors.append(f"{item} 缺少验收")
        for ac_id in ac_ids:
            if ac_id not in acceptance or item not in ids(acceptance[ac_id].get("关联需求")):
                errors.append(f"{item} 与 {ac_id} 的双向映射不一致")
    for item, row in acceptance.items():
        targets = ids(row.get("关联需求"), {"需求", "非功能约束"})
        if not targets:
            errors.append(f"{item} 未关联需求")
        for target in targets:
            if target not in requirements or item not in ids(requirements[target].get("验收")):
                errors.append(f"{item} 与 {target} 的双向映射不一致")

    for item, row in definitions.items():
        if not item.startswith(("问题-", "假设-")):
            continue
        expected = "问题" if item.startswith("问题-") else "假设"
        state, level = row.get("状态"), row.get("影响级别")
        if (row.get("类型") != expected or state not in ASM_STATES
                or level not in ASM_LEVELS):
            errors.append(f"{item} 类型/状态/影响级别非法：类型须为 {'/'.join(ASM_TYPES)}，"
                          f"影响级别须为 {'/'.join(ASM_LEVELS)}，状态须为 {'/'.join(ASM_STATES)}")
        detail = row.get("处理方案/负责人", "")
        if hard_gate(gate):
            if (level == "阻塞" and state == "待处理") or (expected == "假设" and state == "待处理"):
                errors.append(f"{item} 存在未解决阻塞/未接受假设")
            if state in {"已采纳", "已延后"} and not ids(detail, {"决策"}):
                errors.append(f"{item} 接受/移出范围需决策引用")
            if expected == "问题" and state == "已采纳":
                errors.append(f"{item} 问题应解决或移出范围，不能标为已采纳")

    # 人类摘要：新建产品用项目简介，已有项目增量用一页决策摘要。
    if doc_mode(meta) == "增量":
        check_summary(Path(path).parent / SUMMARY_FILE, meta, definitions, errors, warnings, gate)
    else:
        check_intro(Path(path).parent / INTRO_FILE, meta, definitions, errors, warnings, gate)

    # 上游拷问结论：存在就顺手校验（它是 PRD 的原料），缺了不拦——旧项目可能没有这一份。
    conclusion_path = Path(path).parent / CONCLUSION_FILE
    if conclusion_path.is_file():
        upstream = check_conclusion(conclusion_path, "ready")
        for message in upstream["errors"]:
            warnings.append(f"{CONCLUSION_FILE}（上游）{message}")
        if upstream.get("doc_mode") and str(meta.get("doc_mode")) != upstream["doc_mode"]:
            warnings.append(
                f"doc_mode 与 {CONCLUSION_FILE} 不一致：结论写 {upstream['doc_mode']}，"
                f"PRD 写 {meta.get('doc_mode')}——摘要形态会跟着错")
    else:
        warnings.append(
            f"同目录没有 {CONCLUSION_FILE}：它本该由 prd-doc 第 0 步从拷问结果落盘，"
            "PRD 的决策依据无法回查")

    version_section = prefix_map["决策"]
    check_version_records(meta, sections, definitions, errors, warnings, gate, version_section)
    check_prototype(meta, path, definitions, errors, warnings, gate)
    # 空值陈述：1.6.0 起「没有材料」必须写成「未提供：原因」/「不适用：原因」。
    # 两种都记下来，但只有「未提供」算缺口（gaps）：不适用是本产品有意不涉及的事，
    # 不是证据缺失，混进缺口清单会让真正的缺口被淹没。
    empty_claim_hits = []
    if wants_empty_claim_rule(meta):
        empty_claim_hits = check_empty_claims(meta, body, sections, definitions,
                                              errors, warnings, gate)
    gaps = [c for c in empty_claim_hits if c["claim"] == "未提供"]
    not_applicable = sum(1 for c in empty_claim_hits if c["claim"] == "不适用")

    if schema_is_current(meta):
        for number, section in sections.items():
            section_text = "\n".join(section["lines"])
            if section_text.strip() and not SECTION_CONCLUSION.search(section_text):
                (errors if hard_gate(gate) else warnings).append(
                    f"章节 {number} 必须先写一句「本章结论：…」，让读者先拿到判断")
            blocks, current = [], []
            for line in section_text.splitlines() + [""]:
                if line.strip().startswith("|"):
                    current.append(line)
                elif current:
                    blocks.append(current)
                    current = []
            for block in blocks:
                data_rows = max(0, len(block) - 2)
                # 交互规格表是 15 行的两列对照表（v1.1.0 起 15 字段），属正常形态；
                # 超过 16 行才是「表格装不下、该往表外挪」。
                if data_rows > 16:
                    warnings.append(
                        f"章节 {number} 的单个表格超过 14 行，建议拆表或把背景说明移到表格外")
                if any(len(cell) > 160 for line in block for cell in cells(line)):
                    warnings.append(
                        f"章节 {number} 有表格单元格超过 160 字，建议拆成规则条目")

    placeholders = PLACEHOLDER.findall(body + "\n" + json.dumps(meta, ensure_ascii=False, default=str))
    if placeholders:
        (errors if hard_gate(gate) else warnings).append(
            "存在占位/未确认内容：" + ", ".join(sorted(set(placeholders))))
    tone = ai_tone_hits(re.sub(r"(?m)^\s*\|.*$", "", body))
    if tone:
        warnings.append("正文出现 AI 腔/黑话词（PRD 也要人看得懂）：" + "、".join(tone))
    result.update(
        ok=not errors,
        prd_id=meta.get("prd_id"),
        version=meta.get("version"),
        gate=gate,
        doc_mode=meta.get("doc_mode"),
        schema_version=meta.get("schema_version"),
        counts={
            "requirements": len(requirements),
            "acceptance": len(acceptance),
            "interactions": len(interactions),
            "not_applicable": not_applicable,
        },
        not_checked=[
            "方案合理性与取舍质量",
            "事实真伪（脚本只做结构校验）",
            "确认是否真实发生",
            "业务边界完整性",
            "五分钟复述是否实际执行",
            "原型关键状态是否实机走通",
            "原型与 PRD 的行为是否真的一致（反向同步靠逐条确认，脚本不看这一层）",
            "空值陈述写的原因是否成立（脚本只核对「有没有写原因」）",
        ],
        gaps=gaps,
    )
    return result


def resolve_init_dir(directory, project, slug):
    """产物目录：给了 --dir 就用它；给了 --project 就拼 <项目根>/docs/product/<slug>/。

    两者必须且只能给一个——路径不能只靠调用方自己补。
    """
    if bool(directory) == bool(project):
        raise ValueError("--dir 与 --project 必须且只能给一个")
    if directory:
        return directory
    return str(Path(project) / "docs" / "product" / slug)


def init_project(directory, slug, title, local_date, mode="新建"):
    """在 directory 下生成 PRD.md 与人类摘要骨架。

    directory 就是产物目录本身，脚本不拼任何路径——路径由调用方决定
    （``--project`` 会先拼出 <项目根>/docs/product/<slug>/ 再传进来）。
    slug 只用于填 frontmatter 的 prd_id。
    """
    if not re.fullmatch(SLUG_RE, slug):
        raise ValueError("slug 仅允许小写字母、数字和单个连字符")
    if not title:
        raise ValueError("title 不能为空")
    if not valid_date(local_date):
        raise ValueError("date 必须为用户本地 ISO 日期")
    if mode not in DOC_MODES:
        raise ValueError("mode 必须为 新建 或 增量")
    directory = Path(directory)
    kept = []
    if directory.exists():
        existing = sorted(p.name for p in directory.iterdir())
        blocked = [name for name in existing if name not in INIT_KEEPABLE]
        if blocked:
            raise ValueError(
                "项目目录非空，拒绝覆盖；请恢复现有项目或选择新目录"
                f"（已存在：{'、'.join(blocked[:5])}）")
        kept = [name for name in existing if name in INIT_KEEPABLE]
    directory.mkdir(parents=True, exist_ok=True)
    assets = Path(__file__).resolve().parents[1] / "assets"
    replacements = {
        "{{PRD_ID}}": slug,
        "{{DATE}}": local_date,
        "{{MODE}}": mode,
    }
    written = []
    # frontmatter title 用 YAML 单引号字面量：不解释转义，原样保留标题内容。
    single_quoted_title = "'" + title.replace("'", "''") + "'"
    prd_template = "PRD.delta.template.md" if mode == "增量" else "PRD.template.md"
    human_template = "决策摘要.template.md" if mode == "增量" else "项目简介.template.md"
    human_file = SUMMARY_FILE if mode == "增量" else INTRO_FILE
    sources = [
        (prd_template, "PRD.md"),
        (human_template, human_file),
    ]
    for source, target in sources:
        text = (assets / source).read_text(encoding="utf-8")
        text = text.replace('title: "{{TITLE}}"', "title: " + single_quoted_title)
        for token, value in replacements.items():
            text = text.replace(token, value)
        text = text.replace("{{TITLE}}", title)
        (directory / target).write_text(text, encoding="utf-8")
        written.append(target)
    return {
        "ok": True,
        "directory": str(directory.resolve()),
        "files": written,
        "kept": kept,
        "status": PRD_STATUS[0],
        "doc_mode": mode,
    }


def diagnose_prd(path, gate="draft", leading_error=None):
    """对不符合 v1.0 契约的 PRD 做完整、分层的结构诊断。

    常规 check 遇到 frontmatter/表格解析错误会抛 ValueError；命令行层在
    --diagnose 模式下调用本函数，继续报告章节、模式和配套文件缺口，避免
    “只补一个 frontmatter 就以为好了”的误导。
    """
    result = report()
    errors, warnings = result["errors"], result["warnings"]
    if leading_error:
        errors.append(leading_error)
    prd_path = Path(path)
    if not prd_path.is_file():
        errors.append(f"PRD 不存在：{path}")
        result.update(ok=False, errors=errors, warnings=warnings, gate=gate,
                      diagnostics={"prd_exists": False})
        return result
    try:
        text = prd_path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        errors.append(f"PRD 读取失败：{exc}")
        result.update(ok=False, errors=errors, warnings=warnings, gate=gate,
                      diagnostics={"prd_exists": True, "readable": False})
        return result

    meta = {}
    frontmatter_errors = []
    try:
        meta, _, _ = load_frontmatter(prd_path)
    except ValueError as exc:
        frontmatter_errors.append(str(exc))
    errors.extend(frontmatter_errors)
    if str(meta.get("schema_version") or "") not in SCHEMA_VERSIONS:
        if meta:
            errors.append(
                f"不支持的 schema_version：{meta.get('schema_version')}；"
                "本工具只接受 v1.0.0 / v1.1.0 / v1.2.0 / v1.3.0 / v1.4.0 / v1.6.0（当前），旧 PRD 必须重构或显式迁移")
    if meta and not meta.get("doc_mode"):
        errors.append("缺少元数据 doc_mode；v1.0 不允许用旧结构静默升级")
    if "delivery" in meta:
        errors.append("v1.0 已取消 delivery 字段：请删除该键")
    mode = doc_mode(meta)
    expected = headings_for(meta, text)
    found = {}
    for line in text.splitlines():
        m = re.match(r"^##\s+(\d+)\.\s+(.+?)\s*$", line)
        if m:
            found[int(m.group(1))] = m.group(2).strip()
    missing, mismatched = [], []
    for number, title in expected.items():
        if number not in found:
            missing.append(f"{number}. {title}")
        elif found[number] != title:
            mismatched.append(f"{number}: 实际「{found[number]}」应为「{title}」")
    if missing:
        errors.append("缺少规范章节：" + "；".join(missing))
    if mismatched:
        errors.append("章节标题不匹配：" + "；".join(mismatched))

    human = human_file_for(meta)
    if not (prd_path.parent / human).is_file():
        errors.append(f"缺少人类摘要：{human}")
    if (prd_path.parent / "PLAN.md").is_file():
        warnings.append("同目录仍有 PLAN.md：v1.0 已不再产出计划文档，该文件不是契约的一部分，可删除")
    warnings.append("结构诊断不判断方案合理性、事实真伪或确认是否真实发生")
    errors[:] = list(dict.fromkeys(errors))
    warnings[:] = list(dict.fromkeys(warnings))
    result.update(
        ok=not errors,
        gate=gate,
        doc_mode=meta.get("doc_mode"),
        diagnostics={
            "prd_exists": True,
            "readable": True,
            "frontmatter": not frontmatter_errors,
            "frontmatter_errors": frontmatter_errors,
            "schema_version": meta.get("schema_version"),
            "sections_found": found,
            "missing_sections": missing,
            "mismatched_sections": mismatched,
            "human_summary": human,
            "human_summary_exists": (prd_path.parent / human).is_file(),
            "stale_plan_exists": (prd_path.parent / "PLAN.md").is_file(),
        },
        not_checked=[
            "方案合理性与取舍质量",
            "事实真伪（诊断只做结构检查）",
            "确认是否真实发生",
            "业务边界完整性",
            "五分钟复述是否实际执行",
            "原型关键状态是否实机走通",
        ],
    )
    return result


def make_receipt(prd_path, gate, result):
    prd = Path(prd_path)
    files = {}
    human = human_file_for({"doc_mode": result.get("doc_mode")})
    for path in (prd, prd.parent / human):
        if path.is_file():
            files[path.name] = "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()
    # 原型：单文件是 prototype.html，多文件是 prototype.html + prototype.<slug>.html，
    # 全部登记——回执要能证明这份 PRD 是对着哪一版原型签的字。
    for path in prototype_files(prd.parent):
        files[path.name] = "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()
    # 拷问结论是 PRD 的原料，一并留哈希：回执能证明这份 PRD 建在哪份结论上。
    conclusion = prd.parent / CONCLUSION_FILE
    if conclusion.is_file():
        files[conclusion.name] = "sha256:" + hashlib.sha256(conclusion.read_bytes()).hexdigest()
    return {
        "gate": gate,
        "ok": result.get("ok", False),
        "doc_mode": result.get("doc_mode"),
        "files": files,
        "not_checked": result.get("not_checked", []),
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
    }


def replace_once(text, pattern, replacement, label):
    """把唯一一处的匹配替换掉；匹配不到或多于一处都当错误抛出。"""
    matches = list(re.finditer(pattern, text))
    if len(matches) != 1:
        raise ValueError(f"{label}：期望 1 处匹配，实际 {len(matches)} 处（{pattern}）")
    m = matches[0]
    return text[:m.start()] + replacement + text[m.end():]


def bump_version(prd_path, version, local_date, change_type, summary, decisions):
    """升版并同步三处版本标记：PRD frontmatter、摘要锚点、原型 data-prd-version。

    这是同步（正向与反向都一样）的机械收尾动作：版本号只在一处被写入，其余各处
    跟着走，避免「改了 PRD 忘了改原型」这类漂移。多文件原型逐个文件改，草案文件
    没有 data-prd-version，自然不被碰。它不改任何内容，内容由 Agent 负责。
    """
    prd = Path(prd_path)
    if not prd.is_file():
        raise ValueError(f"PRD 不存在：{prd_path}")
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        raise ValueError("version 必须为 x.y.z")
    if not valid_date(local_date):
        raise ValueError("date 必须为用户本地 ISO 日期")
    if change_type not in CHANGE_TYPES:
        raise ValueError("type 必须为 " + "/".join(CHANGE_TYPES))
    if not ids(summary):
        raise ValueError("summary 必须点明受影响的 ID（如 需求-003、验收-005）")
    for phrase in FORBIDDEN_VAGUE:
        if phrase in summary:
            raise ValueError(f"summary 含空话「{phrase}」，需改写为具体改动")
    decision_ids = ids(decisions or "")
    if not decision_ids:
        raise ValueError("decisions 至少要有一个 决策-xxx")

    meta, text, _ = load_frontmatter(prd)
    old_version = str(meta.get("version") or "")
    if old_version == version:
        raise ValueError(f"新版本号与当前版本相同：{version}")
    if old_version and tuple(int(x) for x in version.split(".")) <= tuple(
            int(x) for x in old_version.split(".")):
        raise ValueError(f"版本号必须递增：{old_version} → {version}")

    _, body, sections = load_doc(prd)
    version_section = prefixes_for(meta)["决策"]
    section = sections.get(version_section)
    if not section:
        raise ValueError(f"PRD 缺少第 {version_section} 节，无法追加版本记录")
    section_text = "\n".join(section["lines"])
    if not re.search(r"^###\s*版本记录\s*$", section_text, re.M):
        raise ValueError("缺少「### 版本记录」子表，无法追加")

    rows = version_rows(section_text)
    if not rows:
        raise ValueError("版本记录表为空：初版行必须先由 prd-doc 写好")
    tail = rows[-1][0]
    if tail != old_version:
        raise ValueError(f"版本记录最后一行（{tail}）与 frontmatter version（{old_version}）不一致，先修正再生版")

    new_row = f"| {version} | {local_date} | {change_type} | {summary} | {decisions.strip()} |"
    lines = text.splitlines()
    # 定位版本记录子表里的最后一个数据行，追加到它后面（行只追加，不改写）。
    start = None
    for i, line in enumerate(lines):
        if re.match(r"^###\s*版本记录\s*$", line):
            start = i
            break
    if start is None:
        raise ValueError("在原文里找不到「### 版本记录」标题行")
    last_data = None
    for i in range(start + 1, len(lines)):
        line = lines[i]
        if re.match(r"^###\s+", line):
            break
        if not line.strip().startswith("|"):
            continue
        parts = cells(line)
        if all(re.fullmatch(r":?-{3,}:?", x) for x in parts) or parts[0] == "版本":
            continue
        last_data = i
    if last_data is None:
        raise ValueError("版本记录子表里没有可追加位置")
    lines.insert(last_data + 1, new_row)
    updated = "\n".join(lines)
    if not updated.endswith("\n"):
        updated += "\n"
    updated = replace_once(updated, r"(?m)^version:\s*\"[^\"]*\"\s*$",
                           f'version: "{version}"', "frontmatter version")
    prd.write_text(updated, encoding="utf-8")

    touched = ["PRD.md"]
    human = prd.parent / human_file_for(meta)
    if human.is_file():
        htext = human.read_text(encoding="utf-8-sig")
        new_htext = replace_once(htext, r"PRD[：:]\s*PRD\.md\s*[（(][^）)]*[）)]",
                                 f"PRD：PRD.md（{version}）", "人类摘要版本锚点")
        human.write_text(new_htext, encoding="utf-8")
        touched.append(human.name)
    prototype = prd.parent / str(meta.get("prototype") or "")
    if str(meta.get("prototype") or "").endswith(".html") and prototype.is_file():
        # 多文件原型要逐个改：只改入口会让页面文件的版本停留在旧值，
        # 下一次 check 就会报「data-prd-version 与 PRD 版本不一致」，而作者以为已升版。
        for path in prototype_files(prd.parent):
            ptext = path.read_text(encoding="utf-8-sig")
            if 'data-prd-version="' not in ptext:
                continue  # 草案文件没有版本标记，不该被 bump 碰
            new_ptext = replace_once(ptext, r'data-prd-version="[^"]*"',
                                     f'data-prd-version="{version}"',
                                     f"{path.name} 的 data-prd-version")
            path.write_text(new_ptext, encoding="utf-8")
            touched.append(path.name)
    return {
        "ok": True,
        "from": old_version,
        "to": version,
        "type": change_type,
        "summary": summary,
        "decisions": decisions.strip(),
        "files": touched,
        "next": f"python scripts/prd_tool.py check --prd {prd_path} --gate ready --receipt",
    }


def emit_json(result):
    """把结果打到 stdout，任何情况下都不因控制台编码或管道关闭而崩掉。

    为什么需要这一层：Windows 默认控制台是 GBK（cp936），`sys.stdout.encoding` 实测就是
    `gbk`。此时 `print(json.dumps(..., ensure_ascii=False))` 遇到 emoji（`✅`、`🎯`）会抛
    `UnicodeEncodeError`，整条命令带着 traceback 失败——而中文材料名带个 ✅ 在中文环境里
    再常见不过。脚本挂了，用户拿不到任何结果。

    按优先级试三条，任何一条成功就返回：
      ① 把 stdout 重配成 UTF-8（Python 3.7+ 的 reconfigure，最干净）；
      ② 退化成 ensure_ascii=True（JSON 里中文变 \\uXXXX，机器读得懂，只是人眼不直观）；
      ③ 最后用 backslashreplace 硬写，宁可显示成转义序列也不让命令失败。
    下游提前关管道（`| head`）时 flush 会抛 OSError/BrokenPipeError，这属于正常结束，
    不是错误——一起吞掉，绝不让它盖掉真正的检查结果。
    """
    text = json.dumps(result, ensure_ascii=False, indent=2, default=str)
    stream = sys.stdout
    for attempt in ("utf8", "ascii", "escaped"):
        try:
            if attempt == "utf8":
                if (getattr(stream, "encoding", "") or "").lower() not in ("utf-8", "utf8"):
                    stream.reconfigure(encoding="utf-8", errors="backslashreplace")
                stream.write(text + "\n")
            elif attempt == "ascii":
                stream.write(json.dumps(result, ensure_ascii=True, indent=2, default=str) + "\n")
            else:
                encoding = getattr(stream, "encoding", None) or "ascii"
                stream.write((text + "\n").encode(encoding, "backslashreplace").decode(encoding, "replace"))
            stream.flush()
            return
        except (UnicodeEncodeError, AttributeError, ValueError):
            continue
        except (OSError, BrokenPipeError):
            return  # 管道已关，不是我们的问题


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--project", help="项目根目录；产物写入 <项目根>/docs/product/<slug>/")
    init.add_argument("--dir", help="产物目录（直接指定，脚本不再拼任何路径）")
    init.add_argument("--slug", required=True)
    init.add_argument("--title", required=True)
    init.add_argument("--date", required=True, help="用户本地 ISO 日期，避免运行主机时区造成偏差")
    init.add_argument("--mode", choices=DOC_MODES, default="新建",
                      help="新建：完整产品 PRD；增量：已有项目的本次变化")
    check = sub.add_parser("check")
    check.add_argument("--prd", required=True)
    check.add_argument("--gate", choices=["draft", "ready"], default="draft")
    check.add_argument("--diagnose", action="store_true",
                       help="解析中断时继续输出完整结构诊断；文件能正常解析时只附结构快照（不多列错误）")
    check.add_argument("--receipt", action="store_true",
                       help="附加文件哈希与检查范围回执")
    conclusion = sub.add_parser("conclusion")
    conclusion.add_argument("--file", required=True, help="拷问结论.md 的路径")
    conclusion.add_argument("--gate", choices=["draft", "ready"], default="ready",
                            help="ready=交付硬门（默认）；draft=边写边看，元信息缺失只警告")
    conclusion.add_argument("--receipt", action="store_true",
                            help="附加文件哈希与检查范围回执")
    bump = sub.add_parser("bump")
    bump.add_argument("--prd", required=True)
    bump.add_argument("--version", required=True)
    bump.add_argument("--date", required=True, help="用户本地 ISO 日期")
    bump.add_argument("--type", required=True, choices=CHANGE_TYPES,
                      help="修订=文字/视觉；新增=行为变化；破坏性=已确认约定变化")
    bump.add_argument("--summary", required=True, help="核心修改内容，必须点明受影响的 ID")
    bump.add_argument("--decisions", default="", help="关联决策，逗号分隔的 决策-xxx")
    args = parser.parse_args()
    try:
        if args.command == "init":
            target = resolve_init_dir(args.dir, args.project, args.slug)
            result = init_project(target, args.slug, args.title, args.date, mode=args.mode)
        elif args.command == "conclusion":
            result = check_conclusion(args.file, args.gate)
            if args.receipt and Path(args.file).is_file():
                result["receipt"] = {
                    "gate": args.gate,
                    "ok": result["ok"],
                    "files": {Path(args.file).name: "sha256:" + hashlib.sha256(
                        Path(args.file).read_bytes()).hexdigest()},
                    "not_checked": result.get("not_checked", []),
                    "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
                }
        elif args.command == "bump":
            result = bump_version(args.prd, args.version, args.date, args.type,
                                  args.summary, args.decisions)
        else:
            try:
                result = check_prd(args.prd, args.gate)
            except (OSError, ValueError) as exc:
                if args.diagnose:
                    result = diagnose_prd(args.prd, args.gate, leading_error=str(exc))
                else:
                    raise
            else:
                if args.diagnose:
                    # check 能完整解析时，--diagnose 拿不到额外的错误（旧文档给的预期是反的）。
                    # 与其静默返回一模一样的输出，不如把结构快照附上，并说清它什么时候才有用。
                    probe = diagnose_prd(args.prd, args.gate)
                    result["diagnostics"] = probe.get("diagnostics", {})
                    result["diagnose_note"] = (
                        "本文件能被正常解析，--diagnose 没有额外错误可列（check 本来就一次列全）；"
                        "它只在解析中断（frontmatter / 表格语法坏掉）时才改变结果。"
                        "这里附上的是结构快照。")
            if args.receipt:
                result["receipt"] = make_receipt(args.prd, args.gate, result)
    except (OSError, ValueError) as exc:
        result = {"ok": False, "errors": [str(exc)], "warnings": []}
    emit_json(result)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
