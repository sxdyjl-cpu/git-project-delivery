import { mkdir, mkdtemp, readdir, readFile, writeFile, lstat, rename, rm } from 'node:fs/promises';
import { dirname, join, resolve, isAbsolute } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { gunzipSync } from 'node:zlib';
import { spawnSync } from 'node:child_process';

const skillRoot = fileURLToPath(new URL('../', import.meta.url));
function normalizeUrl(value) {
  if (!value) return '';
  let url; try { url = new URL(value); } catch { throw new Error('项目 URL 不是完整地址'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new Error('项目 URL 仅接受无凭据、无参数的 http(s) 地址');
  if (!url.pathname.endsWith('/')) url.pathname += '/';
  return url.href;
}
async function ensureEmpty(target) {
  try {
    const info = await lstat(target);
    if (info.isSymbolicLink() || !info.isDirectory() || (await readdir(target)).length) throw new Error('目标为已有文件或非空项目，请选择新目录；不会覆盖。');
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
}
export async function initProject(options) {
  const { name, slug, target: requested, version, theme = 'blue' } = options;
  if (!requested || typeof name !== 'string' || !name.trim() || name.trim().length > 80) throw new Error('请提供目标目录与 1–80 字符的项目名称');
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug || '')) throw new Error('slug 使用小写英文、数字和连字符');
  if (typeof version !== 'string' || !version.trim()) throw new Error('请先沿用项目已有版本规划，或与创建者确认迭代版本后显式传入 --version；不自动分配 v0.1。');
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(version)) throw new Error('版本 ID 无法用作目录');
  const site = normalizeUrl(options.siteUrl);
  const repository = normalizeUrl(options.repositoryUrl);
  const target = resolve(requested);
  await ensureEmpty(target);
  const archive = JSON.parse(gunzipSync(await readFile(join(skillRoot, 'assets/starter.json.gz'))).toString('utf8'));
  if (archive.formatVersion !== 1 || !archive.files || typeof archive.files !== 'object') throw new Error('Skill 骨架格式无效');
  for (const [path, content] of Object.entries(archive.files)) {
    if (isAbsolute(path) || path.includes('\\') || path.split('/').some(p => p === '..' || p === '.' || p === '.git' || p.startsWith('.env')) || typeof content !== 'string') throw new Error('Skill 骨架包含不安全路径');
  }
  const agentsTemplate = await readFile(join(skillRoot, 'assets/AGENTS.md'), 'utf8');
  const themeModule = archive.files['src/lib/theme.js'];
  if (!themeModule) throw new Error('Skill 骨架缺少主题配置，请更新 Skill');
  const { themes } = await import(`data:text/javascript;base64,${Buffer.from(themeModule).toString('base64')}`);
  if (!Object.hasOwn(themes, theme)) throw new Error(`主题无效，支持：${Object.keys(themes).join('、')}`);
  await mkdir(dirname(target), { recursive: true });
  const staging = await mkdtemp(join(dirname(target), '.product-init-'));
  try {
    // 兼容骨架内的旧副本；项目协作规则始终从可见的独立模板复制。
    for (const [path, content] of Object.entries(archive.files)) { if (path === 'AGENTS.md') continue; await mkdir(dirname(join(staging, path)), { recursive: true }); await writeFile(join(staging, path), content); }
    await writeFile(join(staging, 'AGENTS.md'), agentsTemplate);
    const project = { name: name.trim(), shortName: Array.from(name.trim())[0], description: `${name.trim()}的产品需求与交互交付空间。`, workspace: name.trim(), storageKey: `project:${slug}:v1`, defaultRoute: 'projects', theme, urls: { site, repository }, demoProjects: [], navigation: [{ id: 'projects', label: '项目', icon: 'grid' }, { id: 'settings', label: '设置', icon: 'settings' }] };
    await mkdir(join(staging, 'config'), { recursive: true });
    await writeFile(join(staging, 'config/project.js'), `// 项目信息会公开；URL 配置不代表已部署。\nexport const project = ${JSON.stringify(project, null, 2)};\n`);
    const data = {
      versions: [{ id: version, label: `${version} · 初始版本`, status: '需求整理中', scopeStatus: 'planning', confirmedAt: null }],
      defaultVersion: version,
      scopes: { baseline: '原始范围', addition: '确认后新增', change: '需求变更' }, decisions: { pending: '待确认', accepted: '已纳入', rejected: '不纳入' },
      modules: [],
      statuses: { ready: '原型就绪', planned: '规划中' }, types: { new: '新增', improvement: '优化', rework: '重构' }, requirements: []
    };
    await writeFile(join(staging, 'config/product.js'), Object.entries(data).map(([key, value]) => `export const ${key} = ${JSON.stringify(value, null, 2)};`).join('\n') + '\n');
    await mkdir(join(staging, `docs/versions/${version}`), { recursive: true });
    await writeFile(join(staging, `docs/versions/${version}/.gitkeep`), '');
    await writeFile(join(staging, 'package.json'), JSON.stringify({ name: slug, version: '0.1.0', private: true, type: 'module', engines: { node: '>=22' }, scripts: { dev: 'node scripts/serve.mjs', start: 'node scripts/serve.mjs', docs: 'node scripts/generate-docs.mjs', 'prepare:content': 'node scripts/prepare.mjs', test: 'node --test tests/*.test.mjs', 'test:browser': 'node tests/browser-smoke.mjs', check: 'node scripts/check.mjs', 'check:staged': 'node scripts/check-staged.mjs', build: 'node scripts/build.mjs', preview: 'node scripts/serve.mjs --dist' } }, null, 2) + '\n');
    await writeFile(join(staging, 'README.md'), `# ${name.trim()}\n\n产品需求、交互 Demo、版本记录和验收成果的 Git 交付仓库。\n\n## 开始\n\n需要 Node.js 22+。在项目根目录运行 \`npm run dev\`，打开终端显示的 HTTP 地址。若双击 \`index.html\`，请按页面提示使用本地服务。根入口展示默认版本，/docs/ 阅读已生成需求。通用规范由 git-project-delivery Skill 提供，不进入交付页面。\n\n## 项目状态\n\n当前是干净的交付骨架，没有代填业务需求；原型为本地交互骨架。接下来根据真实需求修改模块、页面和验收条件。\n\n项目浏览地址：${site || '尚未配置'}。Git 仓库浏览地址：${repository || '尚未配置'}。这些是入口配置，不代表已发布；Git 远端、分支上游与项目所选发布方式需另行核实。\n\n## 协作\n\n需求 ID 关联正文、原型路由、版本范围及验收。文档按 docs/versions/<版本>/需求、 新增、变更组织，在 config/product.js 登记对应关系；说明和交付成果也保存到本版本目录。有实际业务内容后，在本版本 概要/概要总览.md 整理范围与风险，随明细同步维护；空骨架不生成占位概要。已确定版本内追加新增与变更，保留前后规则。修改后运行 npm run prepare:content、npm test、npm run check、npm run build。\n\n按 AGENTS.md 完成同步、提交和推送；实际部署按本项目另行配置的方式执行；不得隐藏他人改动或猜测发布目标。可选浏览器验证先安装 Playwright 与系统 Chrome，再运行 npm run test:browser。\n`);
    for (const script of ['scripts/prepare.mjs', 'scripts/check.mjs']) {
      const result = spawnSync(process.execPath, [script], { cwd: staging, encoding: 'utf8' });
      if (result.status !== 0) throw new Error(`初始化检查失败：${result.stdout}${result.stderr}`);
    }
    const guide = `\n## 项目位置与文件导航\n\n项目根目录：${target}\n\n| 位置 | 用途 |\n| --- | --- |\n| index.html、versions/ | 版本目录与需求索引 |\n| docs/versions/${version}/ | 实际概要、需求、新增、变更及交付正文；当前尚未编写业务内容 |\n| config/product.js | 版本、模块、需求与原型关系 |\n| config/project.js | 项目名称、主题、浏览URL及原型导航 |\n| prototype/、src/prototype/ | 独立原型页面与实现 |\n| src/、assets/ | 目录、文档页面和公共样式 |\n| scripts/、tests/ | 生成、检查、构建和测试 |\n| dist/ | 构建输出，未纳入初始化文件和Git提交 |\n| AGENTS.md | 本项目协作规则 |\n\n[查看初始化文件清单](文件清单.md)。浏览预览前运行 npm run dev，以终端实际地址为准。尚未初始化Git、绑定远端或验证仓库权限。移动整个项目后，以当前根目录为准更新此位置说明。\n`;
    await writeFile(join(staging, 'README.md'), (await readFile(join(staging, 'README.md'), 'utf8')).replace('\n\n', '\n\n' + guide.trim() + '\n\n'));
    await writeFile(join(staging, '文件清单.md'), '');
    const projectFiles = [];
    async function listFiles(directory = '') {
      for (const entry of await readdir(join(staging, directory), { withFileTypes: true })) {
        const path = directory ? `${directory}/${entry.name}` : entry.name;
        if (entry.isDirectory()) await listFiles(path); else projectFiles.push(path);
      }
    }
    await listFiles(); projectFiles.sort();
    await writeFile(join(staging, '文件清单.md'), `# 初始化文件清单\n\n项目根目录：${target}\n\n以下为初始化完成时的 ${projectFiles.length} 个文件，包含本清单；不含尚未生成的依赖、Git内部目录和dist。后续增删以当前项目和Git差异为准，交付时同步核实。\n\n\`\`\`text\n${projectFiles.join('\n')}\n\`\`\`\n`);
    await ensureEmpty(target);
    await rename(staging, target);
    return { target, name: name.trim(), siteUrl: site, theme, readme: join(target, 'README.md'), fileManifest: join(target, '文件清单.md'), fileCount: projectFiles.length, gitInitialized: false, published: false };
  } finally { await rm(staging, { recursive: true, force: true }); }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const options = {};
  const names = { '--target': 'target', '--name': 'name', '--slug': 'slug', '--version': 'version', '--theme': 'theme', '--site-url': 'siteUrl', '--repository-url': 'repositoryUrl' };
  try {
    for (let i = 2; i < process.argv.length; i += 2) {
      if (!names[process.argv[i]] || !process.argv[i + 1]) throw new Error('参数：--target 目录 --name 名称 --slug 标识 --version 已确认版本 [--theme blue] [--site-url 地址] [--repository-url 地址]');
      options[names[process.argv[i]]] = process.argv[i + 1];
    }
    console.log(JSON.stringify(await initProject(options), null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
