import { spawn } from 'node:child_process';
import { access, copyFile, mkdtemp, readFile, realpath, rm } from 'node:fs/promises';
import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { tmpdir } from 'node:os';
import { join, resolve, delimiter, isAbsolute } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { getRepositoryLoginHelp } from './repository-entry.mjs';

const skillRoot = fileURLToPath(new URL('../', import.meta.url));
const helperNames = ['osxkeychain', 'wincred', 'libsecret', 'cache --timeout=3600'];
const failure = (code, message) => ({ ok: false, code, message });
const activeChildren = new Set();
const activeRequests = new Set();
function stopGitOperations() { for (const controller of activeRequests) controller.abort(); for (const child of activeChildren) { try { if (process.platform !== 'win32') process.kill(-child.pid, 'SIGKILL'); else child.kill(); } catch {} } }
export function parseRepository(value, provider) {
  if (typeof value !== 'string' || /[\r\n\0]/.test(value) || /(?:^|\/)\.{1,2}(?:\/|$)/.test(value)) throw new Error('请提供不带凭据的 HTTPS 仓库地址。');
  let url; try { url = new URL(value); } catch { throw new Error('请提供完整的 HTTPS 仓库地址。'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw new Error('仓库地址仅支持 HTTPS，账号和令牌在本机授权窗口单独输入。');
  const parts = url.pathname.replace(/\/+$/, '').split('/').filter(Boolean);
  const inferred = ({ 'github.com': 'github', 'gitlab.com': 'gitlab', 'gitee.com': 'gitee' })[url.hostname] || 'generic';
  provider ||= inferred;
  if (!['github', 'gitlab', 'gitee', 'generic'].includes(provider) || (inferred !== 'generic' && provider !== inferred)) throw new Error('平台与仓库地址不一致。');
  if (!parts.length || (['github', 'gitee'].includes(provider) && parts.length !== 2) || parts.slice(0, -1).some(p => /^(?:-|%2d)$/i.test(p)) || parts.some(p => !/^[\w.%-]+$/.test(p) || /%2e|%2f|%5c/i.test(p) || p === '.' || p === '..')) throw new Error('请使用仓库首页或 HTTPS 克隆地址，不要使用分支、文件或设置页面地址。');
  const originalUrl = url.href;
  url.pathname = '/' + parts.join('/').replace(/\.git$/i, '') + '.git';
  return { url: url.href, originalUrl, webUrl: url.href.replace(/\.git$/, ''), host: url.host, path: url.pathname.slice(1), provider };
}
function cleanEnvironment() {
  const env = { ...process.env };
  const repositoryVariables = /^(?:ALTERNATE_OBJECT_DIRECTORIES|COMMON_DIR|DIR|WORK_TREE|IMPLICIT_WORK_TREE|INDEX_FILE|OBJECT_DIRECTORY|QUARANTINE_PATH|GRAFT_FILE|SHALLOW_FILE|NO_REPLACE_OBJECTS|REPLACE_REF_BASE|PREFIX|INTERNAL_SUPER_PREFIX|NAMESPACE|CEILING_DIRECTORIES|DISCOVERY_ACROSS_FILESYSTEM)$/;
  for (const key of Object.keys(env)) {
    if (/^GIT_(?:TRACE|CONFIG_(?:COUNT|KEY_|VALUE_|PARAMETERS))/.test(key) || ['GIT_CONFIG', 'GIT_CURL_VERBOSE', 'GIT_SSL_NO_VERIFY', 'GIT_EXEC_PATH', 'SSLKEYLOGFILE'].includes(key) || (key.startsWith('GIT_') && repositoryVariables.test(key.slice(4)))) delete env[key];
  }
  return { ...env, GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: 'never', GIT_ASKPASS: 'false', SSH_ASKPASS: 'false' };
}
export function runGit(args, { cwd, env = cleanEnvironment(), input, executable = 'git', timeoutMs = 25000 } = {}) {
  return new Promise(resolveResult => {
    let child;
    try { child = spawn(executable, cwd ? ['-C', cwd, ...args] : args, { env, stdio: ['pipe', 'pipe', 'pipe'], detached: process.platform !== 'win32', windowsHide: true }); }
    catch {
      resolveResult(process.platform === 'darwin' && executable === 'git' ? runGit(args, { cwd, env, input, executable: '/usr/bin/git', timeoutMs }) : { code: 127, stdout: '', stderr: '' }); return;
    }
    activeChildren.add(child);
    let stdout = '', stderr = '', settled = false, stdoutTruncated = false;
    const finish = code => { if (settled) return; settled = true; activeChildren.delete(child); clearTimeout(timer); resolveResult({ code, stdout, stderr, stdoutTruncated }); };
    const timer = setTimeout(() => { try { if (process.platform !== 'win32') process.kill(-child.pid, 'SIGKILL'); else child.kill(); } catch {} finish(124); }, timeoutMs);
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => { if (stdout.length < 262144) stdout += chunk; else stdoutTruncated = true; });
    child.stderr.on('data', chunk => { if (stderr.length < 262144) stderr += chunk; });
    child.on('error', () => {
      if (process.platform === 'darwin' && executable === 'git') {
        settled = true; activeChildren.delete(child); clearTimeout(timer);
        resolveResult(runGit(args, { cwd, env, input, executable: '/usr/bin/git', timeoutMs }));
      } else finish(127);
    }); child.on('close', code => finish(code ?? 1));
    child.stdin.on('error', () => {}); child.stdin.end(input);
  });
}
async function helperAvailable(name, execPath) {
  const binary = 'git-credential-' + name;
  for (const dir of [execPath, ...(process.env.PATH || '').split(delimiter)]) for (const suffix of process.platform === 'win32' ? ['.exe', ''] : ['']) {
    try { await access(join(dir, binary + suffix)); return true; } catch {}
  }
  return false;
}
async function chooseHelper(run) {
  const result = await run(['--exec-path']);
  const execPath = result.code === 0 ? result.stdout.trim() : '';
  const native = process.platform === 'darwin' ? ['osxkeychain'] : process.platform === 'win32' ? ['wincred'] : ['libsecret'];
  for (const name of [...native, 'cache']) if (await helperAvailable(name, execPath)) return name === 'cache' ? 'cache --timeout=3600' : name;
  return null;
}
function storageLabel(helper) { return helper === 'cache --timeout=3600' ? '本机内存缓存（最多 1 小时）' : ({ osxkeychain: 'macOS 钥匙串', wincred: 'Windows 凭据管理器', libsecret: 'Linux 系统密钥环' })[helper]; }
async function context(options, run) {
  const target = resolve(options.target || '.');
  if ((await run(['--version'])).code !== 0) return failure('git_required', '本机尚未安装或无法运行 Git；请让 Skill 协助安装后继续。');
  const repo = await run(['rev-parse', '--show-toplevel'], { cwd: target });
  if (repo.code !== 0) return failure('git_project_required', '当前目录尚未建立 Git 项目；Skill 先建立项目本地仓库，再接入授权。');
  const gitRoot = await realpath(repo.stdout.trimEnd());
  if (await realpath(target) !== gitRoot) {
    return { ...failure('parent_repository', '当前目录位于父级 Git 仓库内。确认沿用父仓库后以仓库根目录接入，或在独立项目目录接入。'), target, gitRoot };
  }
  const origin = await run(['config', '--null', '--get-all', 'remote.origin.url'], { cwd: target });
  if (![0, 1].includes(origin.code) || origin.stdoutTruncated || (origin.code === 0 && !origin.stdout.endsWith('\0'))) return failure('git_config_unavailable', '未能读取项目 Git 远端配置。');
  const originUrls = origin.code === 0 ? origin.stdout.split('\0').slice(0, -1) : [];
  if (originUrls.length > 1) return failure('remote_needs_review', '当前 origin 配置了多个地址，请先核对准确目标。');
  const originUrl = originUrls[0] || '';
  const address = options.repositoryUrl || originUrl;
  if (!address) return failure('repository_required', '请提供要协作的 Git 仓库 HTTPS 地址；不需要填写 Git 命令。');
  let repository; try { repository = parseRepository(address, options.provider); } catch (error) { return failure('invalid_repository', error.message); }
  if (originUrl) {
    let existing; try { existing = parseRepository(originUrl, options.provider); } catch { return failure('remote_needs_review', '当前远端不是可直接接入的 HTTPS 地址；Skill 需先核对目标和连接方式。'); }
    if (existing.url !== repository.url) return failure('remote_mismatch', '当前项目已连接其他仓库；先核对准确目标，不覆盖原远端。');
    repository = { ...repository, url: existing.originalUrl };
  }
  return { ok: true, target: gitRoot, repository, helper: await chooseHelper(run), remoteConfigured: origin.code === 0 };
}
const networkOptions = ['-c', 'protocol.allow=never', '-c', 'protocol.https.allow=always', '-c', 'http.followRedirects=false', '-c', 'http.sslVerify=true', '-c', 'http.lowSpeedLimit=1', '-c', 'http.lowSpeedTime=15'];
const safeHttpOptions = /^http\.(?:.+\.)?(?:proxy|proxyauthmethod|proxysslcainfo|sslbackend|sslcainfo|sslcapath|sslversion|sslcipherlist|pinnedpubkey|schannelcheckrevoke|schannelusesslcainfo)$/;
const reusableCredentialOptions = /^credential\.(?:.+\.)?(?:helper|username|usehttppath)$/;
const extraHeaderOption = /^http\.(?:.+\.)?extraheader$/;
async function transportConfig(target, repository, run, credential) {
  const result = await run(['config', '--null', '--includes', '--get-regexp', '^(url|http|credential)\\.'], { cwd: target });
  if (![0, 1].includes(result.code) || result.stdoutTruncated || (result.stdout && !result.stdout.endsWith('\0'))) return failure('git_config_unavailable', '未能完整读取 Git 传输配置。');
  const entries = [];
  for (const item of result.stdout.split('\0').slice(0, -1)) {
    const separator = item.indexOf('\n');
    const key = separator < 0 ? item : item.slice(0, separator);
    const value = separator < 0 ? 'true' : item.slice(separator + 1);
    const rewrite = /^url\.(.+)\.(?:insteadof|pushinsteadof)$/.exec(key);
    if (rewrite && repository.url.startsWith(value) && rewrite[1] + repository.url.slice(value.length) !== repository.url) {
      return failure('unsafe_git_config', 'Git URL 改写规则会改变本次仓库地址，请先核对目标和改写配置。');
    }
    const reusableHeader = extraHeaderOption.test(key) && (value === '' || /^Authorization:[^\r\n]*$/i.test(value));
    if (safeHttpOptions.test(key) || (!credential && (reusableCredentialOptions.test(key) || reusableHeader))) entries.push([key, value]);
  }
  if (credential) entries.push([`http.${repository.url}.extraHeader`, ''], [`http.${repository.url}.extraHeader`, credential]);
  return { ok: true, entries };
}
function isolatedEnvironment(entries = []) {
  const env = { ...cleanEnvironment(), GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: process.platform === 'win32' ? 'NUL' : '/dev/null' };
  env.GIT_CONFIG_COUNT = String(entries.length);
  for (const [index, [key, value]] of entries.entries()) {
    env[`GIT_CONFIG_KEY_${index}`] = key;
    env[`GIT_CONFIG_VALUE_${index}`] = value;
  }
  return env;
}
async function withTransport(entries, operation) {
  const directory = await mkdtemp(join(tmpdir(), 'git-auth-transport-'));
  // The temporary Git directory prevents Git from reloading URL rewrites and
  // security overrides from local, worktree, or included config during transport.
  try { return await operation({ ...isolatedEnvironment(entries), GIT_DIR: directory }); }
  finally { await rm(directory, { recursive: true, force: true }); }
}
const uncheckedPush = (reason, pushTarget = null) => ({ pushPreflight: 'not_checked', pushPreflightReason: reason, pushTarget });
async function preflight(target, repository, run, env) {
  const head = await run(['rev-parse', '--verify', 'HEAD'], { cwd: target });
  const branch = await run(['symbolic-ref', '--quiet', '--short', 'HEAD'], { cwd: target });
  if (head.code !== 0 || branch.code !== 0) return uncheckedPush('branch_or_commit_required');
  const name = branch.stdout.trim();
  const remote = await run(['config', '--get', `branch.${name}.remote`], { cwd: target });
  const merge = await run(['config', '--get-all', `branch.${name}.merge`], { cwd: target });
  const remoteName = remote.stdout.trim();
  const ref = merge.stdout.trim();
  if (remote.code !== 0 || merge.code !== 0 || !remoteName || remoteName === '.' || !ref.startsWith('refs/heads/') ||
      (await run(['check-ref-format', ref], { cwd: target })).code !== 0) return uncheckedPush('upstream_required');
  const urls = await run(['remote', 'get-url', '--push', '--all', '--', remoteName], { cwd: target });
  if (urls.code !== 0 || !urls.stdout.trim() || urls.stdout.trim().includes('\n')) return uncheckedPush('single_push_url_required');
  let url;
  try { url = parseRepository(urls.stdout.trim()).originalUrl; }
  catch { return uncheckedPush('unsupported_push_url'); }
  const pushTarget = { url, ref };
  if (url !== repository.url) return uncheckedPush('different_push_url', pushTarget);
  const objectInfo = await run(['rev-parse', '--path-format=absolute', '--git-path', 'objects', '--show-object-format', '--is-shallow-repository'], { cwd: target });
  const [objects, objectFormat, shallow] = objectInfo.stdout.trimEnd().split('\n');
  const source = head.stdout.trim();
  if (objectInfo.code !== 0 || !isAbsolute(objects) || !['sha1', 'sha256'].includes(objectFormat) || !['true', 'false'].includes(shallow) || !/^(?:[\da-f]{40}|[\da-f]{64})$/.test(source)) return uncheckedPush('transport_setup_failed', pushTarget);
  const scratch = await run(['init', '--bare', '--template=', `--object-format=${objectFormat}`], { cwd: target, env: { ...isolatedEnvironment(), GIT_DIR: env.GIT_DIR } });
  if (scratch.code !== 0) return uncheckedPush('transport_setup_failed', pushTarget);
  if (shallow === 'true') {
    const shallowPath = await run(['rev-parse', '--path-format=absolute', '--git-path', 'shallow'], { cwd: target });
    if (shallowPath.code !== 0) return uncheckedPush('transport_setup_failed', pushTarget);
    try { await copyFile(shallowPath.stdout.trimEnd(), join(env.GIT_DIR, 'shallow')); }
    catch { return uncheckedPush('transport_setup_failed', pushTarget); }
  }
  const result = await run([...networkOptions, 'push', '--dry-run', '--no-verify', url, `${source}:${ref}`], { cwd: target, env: { ...env, GIT_ALTERNATE_OBJECT_DIRECTORIES: JSON.stringify(objects) } });
  return { pushPreflight: result.code === 0 ? 'passed' : 'failed', pushTarget };
}
export async function inspectGitAccess(options = {}, { run = runGit } = {}) {
  const info = await context(options, run); if (!info.ok) return info;
  const { target, repository, helper } = info;
  const config = await transportConfig(target, repository, run); if (!config.ok) return config;
  const { result, push } = await withTransport(config.entries, async env => {
    const result = await run([...networkOptions, 'ls-remote', '--symref', repository.url, 'HEAD'], { cwd: target, env });
    const push = result.code === 0 ? await preflight(target, repository, run, env) : uncheckedPush('read_failed');
    return { result, push };
  });
  const name = await run(['config', 'user.name'], { cwd: target });
  const email = await run(['config', 'user.email'], { cwd: target });
  return { ...info, credentialStore: helper ? storageLabel(helper) : null, read: result.code === 0 ? 'passed' : 'failed', identityConfigured: name.code === 0 && !!name.stdout.trim() && email.code === 0 && !!email.stdout.trim(), ...push, pushVerified: false };
}
async function saveCredential({ target, repository, username, secret, helper, signal }, run, env) {
  const safeHelper = ['-c', 'credential.helper=', '-c', `credential.helper=${helper}`, '-c', 'credential.useHttpPath=true'];
  const description = `url=${repository.url}\nusername=${username}\n`;
  const previousCredential = await run([...safeHelper, 'credential', 'fill'], { cwd: target, env, input: description + '\n' });
  // Git 无凭据时通常返回 128；超时、启动失败与取消不能当作“没有旧值”。
  if (signal?.aborted || ![0, 1, 128].includes(previousCredential.code)) return false;
  const changes = [[`credential.${repository.url}.helper`, ['', helper]], [`credential.${repository.url}.useHttpPath`, ['true']], [`credential.${repository.url}.username`, [username]]];
  const before = [];
  for (const [key] of changes) {
    const old = await run(['config', '--local', '--get-all', key], { cwd: target });
    if (![0, 1].includes(old.code)) return false;
    before.push([key, old.code === 0 ? old.stdout.replace(/\n$/, '').split('\n') : []]);
  }
  const restoreCredential = () => run([...safeHelper, 'credential', previousCredential.code === 0 ? 'approve' : 'reject'], { cwd: target, env, input: previousCredential.code === 0 ? previousCredential.stdout + '\n' : description + '\n' });
  if (signal?.aborted) return false;
  const stored = await run([...safeHelper, 'credential', 'approve'], { cwd: target, env, input: description + `password=${secret}\n\n` });
  if (stored.code !== 0) { await restoreCredential(); return false; }
  const saved = await run([...safeHelper, 'credential', 'fill'], { cwd: target, env, input: description + '\n' });
  const password = saved.stdout?.split('\n').find(line => line.startsWith('password='))?.slice(9);
  if (signal?.aborted || saved.code !== 0 || password !== secret) { await restoreCredential(); return false; }
  for (const [key, values] of changes) {
    const first = await run(['config', '--local', '--replace-all', key, values[0]], { cwd: target });
    let ok = first.code === 0;
    for (const value of values.slice(1)) if ((await run(['config', '--local', '--add', key, value], { cwd: target })).code !== 0) ok = false;
    if (!ok || signal?.aborted) {
      for (const [oldKey, oldValues] of before) { await run(['config', '--local', '--unset-all', oldKey], { cwd: target }); for (const value of oldValues) await run(['config', '--local', '--add', oldKey, value], { cwd: target }); }
      await restoreCredential();
      return false;
    }
  }
  return true;
}
export async function verifyWriteChannel(repository, username, secret, { request = fetch, signal } = {}) {
  if (request === fetch && process.env.NODE_TLS_REJECT_UNAUTHORIZED === '0') return false;
  const controller = new AbortController(); activeRequests.add(controller);
  const timeout = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await request(repository.url.replace(/\/+$/, '') + '/info/refs?service=git-receive-pack', { redirect: 'error', signal: signal ? AbortSignal.any([controller.signal, signal]) : controller.signal, headers: { authorization: `Basic ${Buffer.from(username + ':' + secret).toString('base64')}`, accept: 'application/x-git-receive-pack-advertisement' } });
    if (response.status !== 200 || !/^application\/x-git-receive-pack-advertisement(?:;|$)/i.test(response.headers.get('content-type') || '')) { await response.body?.cancel(); return false; }
    const reader = response.body.getReader();
    let prefix = ''; const decoder = new TextDecoder();
    while (prefix.length < 1024 && !prefix.includes('\n')) {
      const chunk = await reader.read(); if (chunk.done) break;
      prefix += decoder.decode(chunk.value.slice(0, 1024 - prefix.length), { stream: true });
    }
    await reader.cancel();
    return /^001f# service=git-receive-pack\n/.test(prefix);
  } catch { return false; }
  finally { clearTimeout(timeout); activeRequests.delete(controller); }
}
export async function authorizeRepository(input, { run = runGit, verifyWrite = verifyWriteChannel } = {}) {
  const { target, repository, username, secret, mode, helper, signal } = input;
  const rawRun = run;
  run = (args, options) => signal?.aborted ? Promise.resolve({ code: 130, stdout: '', stderr: '' }) : rawRun(args, options);
  const cancelled = () => failure('session_closed', '授权窗口已关闭，未完成的接入已取消。');
  if (signal?.aborted) return cancelled();
  if (!['token', 'password'].includes(mode) || typeof username !== 'string' || !username.trim() || username.length > 256 || /[:\r\n\0]/.test(username) || typeof secret !== 'string' || !secret || secret.length > 8192 || /[\r\n\0]/.test(secret)) return failure('invalid_credentials', '请填写账号及令牌或密码，不要包含换行。');
  if (repository.provider === 'github' && mode === 'password') return failure('token_required', 'GitHub 的 Git 操作需使用令牌，不支持账号密码。请选择令牌方式。');
  if (!helperNames.includes(helper)) return failure('secure_store_required', '本机缺少可用的安全凭据组件，Skill 将协助配置；不会明文保存令牌。');
  const config = await transportConfig(target, repository, run, `Authorization: Basic ${Buffer.from(username + ':' + secret).toString('base64')}`);
  if (signal?.aborted) return cancelled();
  if (!config.ok) return config;
  const { read, push } = await withTransport(config.entries, async env => {
    const read = await run([...networkOptions, 'ls-remote', '--symref', repository.url, 'HEAD'], { cwd: target, env });
    return { read, push: read.code === 0 ? await preflight(target, repository, run, env) : uncheckedPush('read_failed') };
  });
  if (signal?.aborted) return cancelled();
  if (read.code !== 0) return failure('access_failed', '连接未通过：请核对账号、凭据有效期、仓库权限、网络及地址。未写入新凭据。');
  const { pushPreflight } = push;
  if (signal?.aborted) return cancelled();
  if (pushPreflight !== 'passed' && !await verifyWrite(repository, username, secret, { signal })) return signal?.aborted ? cancelled() : failure('write_access_failed', '读取已通过，写入通道尚未验证：请核对写权限、成员权限，以及 Git/Node 的代理和可信证书配置。未保存本次凭据，也未推送。');
  if (signal?.aborted) return cancelled();
  if (!await withTransport([], env => saveCredential(input, rawRun, env))) return signal?.aborted ? cancelled() : failure('credential_save_failed', '连接可读取，但凭据保存未完成。Skill 需检查本机安全存储与项目配置。');
  const message = {
    passed: '凭据已接入，推送预检通过。实际写入权限以之后的真实提交推送结果为准。',
    failed: '读取已通过，推送预检未通过；Skill 会继续检查写权限、分支规则或远端更新。尚未实际推送。',
    not_checked: '凭据已接入，仓库可读取。尚未验证目标分支的推送权限。'
  }[pushPreflight];
  return { ok: true, repository: repository.webUrl, username, read: 'passed', writeChannel: 'passed', credentialStore: storageLabel(helper), ...push, pushVerified: false, message };
}
export async function authorizeWithBrowser({ target, repository, helper, signal }, { run = runGit, authorize = authorizeRepository } = {}) {
  const url = new URL(repository.url);
  const browserProviders = new Map([['github.com', 'github'], ['gitlab.com', 'gitlab']]);
  const provider = browserProviders.get(url.host);
  if (!provider || provider !== repository.provider) {
    return failure('browser_login_unsupported', '此服务使用团队配置的登录方式。可以复用已有凭据，或在本机窗口填写令牌或平台允许的账号密码。');
  }
  if (!helperNames.includes(helper)) return failure('secure_store_required', '本机缺少可用的安全凭据存储。');
  const incomplete = () => failure('browser_login_failed', '浏览器登录未完成。可以重新打开授权，或使用本机窗口填写已有令牌或平台允许的账号密码。');
  if (signal?.aborted) return incomplete();
  const checked = parseRepository(url.href, provider);
  repository = { ...checked, url: checked.originalUrl };
  const transport = await transportConfig(target, repository, run);
  if (!transport.ok) return transport;
  if (signal?.aborted) return incomplete();
  const result = await withTransport([], async env => {
    // Use GCM's built-in provider endpoints and leave credential storage to authorizeRepository.
    for (const key of Object.keys(env)) if (key.startsWith('GCM_')) delete env[key];
    const manager = await run(['credential-manager', '--version'], { cwd: env.GIT_DIR, env });
    if (signal?.aborted) return incomplete();
    if (manager.code !== 0) return failure('credential_manager_required', '本机未找到 Git Credential Manager。可使用官方凭据组件，或在本机窗口填写已有令牌。');
    const credential = await run(['credential-manager', 'get'], {
      cwd: env.GIT_DIR,
      env: {
        ...env, GCM_INTERACTIVE: 'true', GCM_PROVIDER: provider, GCM_CREDENTIAL_STORE: 'none',
        GCM_GITHUB_AUTHMODES: 'browser', GCM_GITLAB_AUTHMODES: 'browser',
      },
      input: `protocol=https\nhost=${url.host}\npath=${url.pathname.slice(1)}\n\n`,
      timeoutMs: 300000,
    });
    if (signal?.aborted || credential.code !== 0 || credential.stdoutTruncated) return incomplete();
    const fields = new Map();
    for (const line of credential.stdout.split(/\r?\n/)) {
      const separator = line.indexOf('=');
      if (separator !== -1) fields.set(line.slice(0, separator), line.slice(separator + 1));
    }
    const username = fields.get('username');
    const secret = fields.get('password');
    if (!username || !secret) return incomplete();
    return authorize({ target, repository, helper, signal, username, secret, mode: 'token' }, { run });
  });
  return result.ok ? { ...result, authentication: 'browser' } : result;
}
export async function startAuthorization(options, { authorize = authorizeRepository } = {}) {
  const nonce = randomBytes(24).toString('hex');
  const scriptNonce = randomBytes(18).toString('hex');
  const template = await readFile(join(skillRoot, 'assets/git-login.html'), 'utf8');
  let origin, busy = false, completed = false, attempts = 0, timer, pending, closing;
  const cancellation = new AbortController();
  let complete; const finished = new Promise(resolve => { complete = resolve; });
  const server = createServer(async (req, res) => {
    const headers = { 'cache-control': 'no-store', 'referrer-policy': 'no-referrer', 'x-frame-options': 'DENY', 'x-content-type-options': 'nosniff', 'content-security-policy': `default-src 'none'; script-src 'nonce-${scriptNonce}'; style-src 'nonce-${scriptNonce}'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'` };
    const send = (status, body, type = 'application/json') => { res.writeHead(status, { ...headers, 'content-type': `${type}; charset=utf-8` }); res.end(type === 'application/json' ? JSON.stringify(body) : body); };
    if (req.headers.host !== new URL(origin).host) return send(403, failure('invalid_host', '请求来源不匹配。'));
    if (req.method === 'GET' && req.url === `/${nonce}/`) {
      const context = JSON.stringify({
        repository: options.repository.webUrl, provider: options.repository.provider,
        storage: storageLabel(options.helper) || '未配置', help: getRepositoryLoginHelp(options.repository),
      }).replaceAll('<', '\\u003c');
      return send(200, template.replaceAll('__NONCE__', scriptNonce).replace('__CONTEXT__', context), 'text/html');
    }
    if (req.method !== 'POST' || ![`/${nonce}/authorize`, `/${nonce}/cancel`].includes(req.url)) return send(404, failure('not_found', '页面不存在。'));
    if (req.headers.origin !== origin || !/^application\/json(?:;|$)/i.test(req.headers['content-type'] || '')) return send(403, failure('invalid_origin', '请从本机授权窗口提交。'));
    if (req.url === `/${nonce}/cancel`) { res.once('finish', () => { void close(); }); return send(200, failure('session_closed', '已取消，可返回 Skill。')); }
    if (completed || busy || attempts >= 5) return send(409, failure('session_unavailable', '当前会话已完成、正在验证或尝试次数已用完，请回到 Skill 继续。'));
    busy = true;
    try {
      let body = ''; for await (const chunk of req) { body += chunk; if (Buffer.byteLength(body) > 16384) { send(413, failure('too_large', '输入过长。')); return; } }
      const data = JSON.parse(body); attempts++;
      pending = Promise.resolve(authorize({ target: options.target, repository: options.repository, helper: options.helper, signal: cancellation.signal, username: data.username, secret: data.secret, mode: data.mode }));
      const result = await pending;
      if (cancellation.signal.aborted) return;
      send(result.ok ? 200 : 400, result);
      if (result.ok) { completed = true; complete(result); clearTimeout(timer); server.close(); }
    } catch { send(400, failure('request_failed', '未完成验证，请核对输入后重试。')); }
    finally { busy = false; }
  });
  server.keepAliveTimeout = 1000;
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  origin = `http://127.0.0.1:${server.address().port}`;
  const close = () => closing ||= (async () => {
    cancellation.abort(); stopGitOperations(); clearTimeout(timer);
    await new Promise(resolve => { server.close(resolve); server.closeAllConnections(); });
    try { await pending; } catch {}
    complete(failure('session_closed', '授权窗口已关闭，尚未完成的操作不会报告成功。'));
  })();
  timer = setTimeout(close, options.timeoutMs || 600000);
  return { url: `${origin}/${nonce}/`, finished, close };
}
function openLocalPage(url) {
  const [command, args] = process.platform === 'darwin' ? ['open', [url]] : process.platform === 'win32' ? ['rundll32', ['url.dll,FileProtocolHandler', url]] : ['xdg-open', [url]];
  const child = spawn(command, args, { stdio: 'ignore', detached: true }); child.on('error', () => {}); child.unref();
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const action = process.argv[2]; const options = {}; const names = { '--target': 'target', '--repository-url': 'repositoryUrl', '--provider': 'provider' };
    for (let i = 3; i < process.argv.length; i++) { if (process.argv[i] === '--no-open') { options.noOpen = true; continue; } if (!names[process.argv[i]] || !process.argv[i + 1]) throw new Error('参数：inspect|login|browser-login --target 项目目录 [--repository-url HTTPS仓库地址] [--provider github|gitlab|gitee|generic] [--no-open]；凭据只能在本机授权页填写。'); options[names[process.argv[i]]] = process.argv[++i]; }
    if (action === 'inspect') console.log(JSON.stringify(await inspectGitAccess(options), null, 2));
    else if (action === 'browser-login') {
      const info = await context(options, runGit);
      const controller = new AbortController();
      const cancel = () => { controller.abort(); stopGitOperations(); };
      for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, cancel);
      const result = info.ok ? await authorizeWithBrowser({ ...info, signal: controller.signal }) : info;
      console.log(JSON.stringify(result, null, 2));
      if (!result.ok) process.exitCode = 1;
    }
    else if (action === 'login') {
      const info = await context(options, runGit);
      if (!info.ok || !info.helper) { console.log(JSON.stringify(info.ok ? failure('secure_store_required', '请让 Skill 配置系统凭据组件后继续。') : info, null, 2)); process.exitCode = 1; }
      else {
        const service = await startAuthorization(info);
        for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await service.close(); process.exit(1); });
        console.log(`本机授权窗口：${service.url}`);
        if (!options.noOpen) openLocalPage(service.url);
        const result = await service.finished; console.log(JSON.stringify(result, null, 2)); if (!result.ok) process.exitCode = 1;
      }
    } else throw new Error('请选择 inspect（检测）、login（本机授权）或 browser-login（平台浏览器登录）。');
  } catch { console.error('未完成 Git 接入。请核对项目目录、无凭据的 HTTPS 仓库地址及脚本参数。'); process.exitCode = 1; }
}
