import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const providers = {
  github: {
    origin: 'https://github.com',
    createPath: '/new',
    tokenPath: '/settings/personal-access-tokens/new',
    tokenMessage: '在 GitHub 选择对应的仓库。需要推送时，给令牌授予该仓库的 Contents 读写权限。',
  },
  gitlab: {
    origin: 'https://gitlab.com',
    createPath: '/projects/new',
    tokenPath: '/-/user_settings/personal_access_tokens',
    tokenMessage: '在 GitLab 创建令牌。只读取时选择 read_repository，需要推送时选择 write_repository。',
  },
  gitee: {
    origin: 'https://gitee.com',
    createPath: '/projects/new',
    tokenPath: '/profile/personal_access_tokens',
    tokenMessage: '在 Gitee 的个人设置中创建私人令牌，选择与本次操作相符的拉取或推送权限。',
  },
};
const namePattern = /^[a-z\d][a-z\d._-]{0,99}$/i;

function httpsAddress(value) {
  if (typeof value !== 'string' || !/^https:\/\//i.test(value) || /[\s\\]/u.test(value)) return null;
  try {
    const url = new URL(value);
    return url.username || url.password || /[?#]/.test(value) ? null : url;
  } catch {
    return null;
  }
}

export function prepareRepositoryEntry({ provider, name, owner, visibility = 'private', createPageUrl } = {}) {
  provider ||= createPageUrl ? 'generic' : undefined;
  if (!provider) {
    return { status: 'platform_required', createUrl: null, message: '先选团队使用的 Git 平台，或提供公司自建服务的仓库创建页面。' };
  }
  if (provider !== 'generic' && !Object.hasOwn(providers, provider)) throw new Error('请选择 GitHub、GitLab、Gitee 或自建 Git 服务。');
  if (!['private', 'public'].includes(visibility)) throw new Error('请确认仓库可见性为私有或公开。');
  if (name && (typeof name !== 'string' || !namePattern.test(name) || /\.git$/i.test(name))) throw new Error('仓库名称使用以字母或数字开头的英文标识，可包含点、连字符和下划线。');
  if (owner && (typeof owner !== 'string' || !owner.split('/').every(part => namePattern.test(part)) ||
      (['github', 'gitee'].includes(provider) && owner.includes('/')))) throw new Error('请填写该平台上的有效账号或团队路径。');
  const customUrl = createPageUrl && httpsAddress(createPageUrl);
  if (createPageUrl && (provider !== 'generic' || !customUrl)) throw new Error('自建服务请使用已核对且不带凭据、参数或片段的 HTTPS 创建页面。');
  const details = { provider, name, owner, visibility };
  const missing = ['name', 'owner'].filter(key => !details[key]);
  if (missing.length) {
    return { ...details, status: 'details_required', missing, createUrl: null, message: '先确认仓库名称和所属账号或团队。' };
  }
  if (provider === 'generic' && !customUrl) {
    return { ...details, status: 'create_page_required', createUrl: null, message: '请使用团队平台的仓库创建入口，或提供已确认的创建页面。' };
  }
  const platform = providers[provider];
  const url = customUrl || new URL(platform.createPath, platform.origin);
  if (provider === 'github') url.search = new URLSearchParams({ name, owner, visibility }).toString();
  return { ...details, status: 'create_ready', createUrl: url.href, message: '在创建页面核对仓库归属和可见性，创建后复制仓库链接继续。' };
}

export function getRepositoryLoginHelp(repository) {
  const platform = Object.hasOwn(providers, repository?.provider) ? providers[repository.provider] : null;
  const url = httpsAddress(repository?.url);
  if (platform && url?.origin === platform.origin) {
    return { tokenUrl: new URL(platform.tokenPath, platform.origin).href, message: platform.tokenMessage };
  }
  return { tokenUrl: null, message: '按团队 Git 平台的登录指引获取仓库凭据。需要推送时，请确认账号或令牌有写入权限。' };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const flags = new Map([
    ['--provider', 'provider'], ['--name', 'name'], ['--owner', 'owner'],
    ['--visibility', 'visibility'], ['--create-page-url', 'createPageUrl'],
  ]);
  try {
    const options = {};
    for (let i = 2; i < process.argv.length; i += 2) {
      const key = flags.get(process.argv[i]);
      const value = process.argv[i + 1];
      if (!key || !value || value.startsWith('--') || Object.hasOwn(options, key)) throw new Error('请传入正确的仓库入口参数。');
      options[key] = value;
    }
    console.log(JSON.stringify(prepareRepositoryEntry(options), null, 2));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
