import assert from 'node:assert/strict';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createServer } from '../scripts/serve.mjs';
import { root } from '../scripts/generate-docs.mjs';
import { build } from '../scripts/build.mjs';
import { versions, requirements, defaultVersion } from '../config/product.js';
import { project } from '../config/project.js';
import { documents } from '../assets/generated/documents.js';
import { normalizeProjectUrl } from '../src/lib/product.js';
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
let browser, server, profile;
async function cleanup() {
  if (browser) { await browser.close(); browser = null; }
  if (server) { await new Promise(resolve => server.close(resolve)); server = null; }
  if (profile) { await rm(profile, { recursive: true, force: true }); profile = null; }
}
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await cleanup(); process.exit(1); });
try {
  await build();
  server = createServer(join(root, 'dist'));
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const temporary = join(tmpdir(), 'product-template-e2e'); await mkdir(temporary, { recursive: true }); profile = await mkdtemp(join(temporary, 'run-'));
  browser = await chromium.launchPersistentContext(profile, { channel: 'chrome', headless: true });
  await mkdir(join(root, 'test-results'), { recursive: true });
  const page = await browser.newPage(); const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 900 });
    for (const path of ['/', ...versions.map(v => `/versions/${v.id}/`), '/docs/', '/prototype/', ...versions.map(v => `/docs/?version=${encodeURIComponent(v.id)}&view=changes`)]) {
      const response = await page.goto(base + path, { waitUntil: 'networkidle' });
      assert.equal(response.status(), 200);
      assert.ok((await page.title()).endsWith(` · ${project.name}`), path);
      if (path === '/' || path.startsWith('/versions/')) assert.equal(await page.locator('#overview-project-name').textContent(), project.name);
      if (path === '/docs/') assert.equal(await page.locator('#doc-brand-name').textContent(), project.name);
      assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), path);
      assert.equal(await page.getByRole('combobox', { name: '主题颜色', exact: true }).inputValue(), project.theme || 'blue');
      if (path === '/' && project.urls?.site) assert.equal(await page.getByRole('link', { name: '浏览项目' }).getAttribute('href'), normalizeProjectUrl(project.urls.site));
      if (path === '/' && requirements.length === 0) await page.getByRole('heading', { name: '尚未登记需求', exact: true }).waitFor();
      if (path === '/docs/' && !documents.some(doc => doc.version === defaultVersion)) await page.getByRole('heading', { name: '本版本尚无文档', exact: true }).waitFor();
      if (path.includes('view=changes') && !requirements.some(r => r.version === new URL(base + path).searchParams.get('version') && ['addition', 'change'].includes(r.scope))) await page.getByRole('heading', { name: '本版本暂无变更需求', exact: true }).waitFor();
      if (path === '/') await page.screenshot({ path: join(root, `test-results/overview-${width}.png`), fullPage: true });
    }
  }
  assert.deepEqual(errors, []);
  console.log('全部版本、产品文档和原型入口的桌面/窄屏检查通过；业务交互需按实际需求补充用例。');
} finally { await cleanup(); }
