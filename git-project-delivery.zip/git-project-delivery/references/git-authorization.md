# 首次 Git 接入与账号授权

用户可以贴上已有 Git 仓库链接，也可以让 Skill 协助建仓。Skill 检查本机环境、连接远端并处理 Git 命令。用户可复用现有登录或 SSH 密钥，也可使用平台登录，或在本机窗口填写令牌及平台允许的账号密码。仓库读写权限由平台和仓库管理员决定。

## 首次状态提示与父级仓库

本节适用于首次构建/接入，后续普通小改动不重复询问已确定的目标。先离线读取 git rev-parse --show-toplevel、当前分支与配置的远端，对照用户指定目录；输出仓库链接前去除用户名、密码和查询参数，不输出凭据。

向用户报告仓库归属、目标、读取权限、推送预检和实际推送状态。未执行的检查写“未验证”，不能写“无权限”或“已授权”。例如：

> 当前项目位于父级 sunxiaodong 仓库中，尚无独立项目仓库。本次只完成本地构建与提交；远端读取和写入权限未验证。独立接入还需要项目仓库地址。

用户只要求本地时不触发登录或在线检查，但仍说明该状态；用户需要远端协作时，目标已明确就直接接续检测，缺少地址再问链接。已检测通过的凭据可复用，不为展示授权流程强制重新登录。仅有已配置的 SSH 地址也不能推断已验证登录；当前 HTTPS 登录脚本不替代 SSH 连接检查。

父级仓库不等于用户想要的项目仓库。选择未明确时让用户决定沿用父仓库、独立接入或仅本地；已明确则不重复询问。独立接入应在父仓库外的独立目录操作；目标仓库已有历史时先按其历史接入，再增量复制本项目交付文件并保留来源 SHA。目标为空时才建立相应初始历史。不得重绑父仓库远端，不默认提交父仓库其他内容，也不在原目录擅自 git init 嵌套仓库。完成目标检查与授权后，真实推送仍按当前任务范围决定。

## 从自然语言到连接

1. 读取目标项目自己的 AGENTS.md、工作区、Git根目录、远端和上游，先按上节向用户说明归属及尚未验证的状态。已有可用 SSH/HTTPS 凭据优先复用，不重复登录。连接器账号与本地 Git 凭据分别核实；连接器能看仓库不代表本地能推送。
2. 自动检查 Node.js 22+、Git 和安全凭据组件。缺少工具时按当前系统与用户授权协助安装，遵守系统审批；不要把一串安装或 Git 命令丢给用户。无法安装时说明准确缺项，保留本地成果。
3. 从已确认的远端或用户提供的链接识别平台。还没有仓库时，按下节协助新建。
4. 新项目在准确目录建立本地 Git 仓库，已有项目保留历史。先检查已有 HTTPS 或 SSH 凭据。需要登录时按下方方式引导，并在用户完成后接续。真实凭据输入由用户在本机窗口或平台完成。
5. 用户完成输入后，脚本检查 HTTPS 读取，并按当前分支的跟踪远端、实际推送 URL 和上游分支做预检。无法预检或预检未通过时可检查当前授权仓库的写入服务，再验证安全存储回读。写入服务通过只用于凭据接入，不能替代实际推送目标的预检。失败时按结果处理，不能把公共仓库的匿名读取当作账号或令牌已验证。仅预检不产生远端提交或临时测试分支。
6. 凭据接入后，由 Skill 为同一目标核对/配置 origin 和上游，获取远端并保留历史；仅在没有原远端时添加，不覆盖其他仓库。新建或切换任务分支遵守团队规则。提交身份缺失时只问姓名和邮箱，配置到本项目，不改全局身份；它们是提交署名，与登录密码无关。
7. 根据当前任务和项目约定完成真实修改、验证、同步、提交和推送。先比较远端历史，不 force、不 stash 隐藏他人修改；推送后核对准确分支 SHA。只做授权的请求不自动推送工作区已有内容。连接成功、预检通过、真实推送成功分别报告。

用户只需说：

> 使用 $git-project-delivery，把当前项目接入 https://git.example.com/team/product.git，并帮我完成首次推送。

## 还没有远端仓库

先用已有信息确定团队平台、所属账号或团队、仓库名称与可见性。缺少平台时，请用户选择 GitHub、GitLab、Gitee 或团队自建服务。建议使用私有仓库，用户可指定其他可见性。已有本地文件时选择空仓库，后续由 Skill 提交初始内容。

有已登录且具备建仓权限的连接器、官方工具或浏览器会话时，在用户授权的目标下协助建仓。无法代为提交建仓表单时，打开对应平台的创建入口，将已确认的名称、归属和可见性告诉用户，请用户完成平台操作。完成后核对平台实际生成的克隆地址，再接续连接和首次推送。自建服务使用团队提供的入口。

`repository-entry.mjs` 会为 Agent 生成平台创建入口和建仓参数。它只准备表单入口，创建结果以平台为准。

```bash
node <skill-dir>/scripts/repository-entry.mjs --provider github --owner <归属> --name <仓库名> --visibility private
```

GitHub 创建页可预填仓库信息，GitLab 和 Gitee 使用其创建页。自建服务提供明确的 HTTPS 创建页地址时，可通过 `--create-page-url` 使用。[GitHub 建仓](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository) · [GitLab 建仓](https://docs.gitlab.com/user/project/) · [Gitee 创建仓库](https://gitee.com/projects/new)

## 选择授权方式

- **已有 SSH 密钥**。使用仓库提供的 SSH 克隆地址，按该主机的信任配置非交互验证远端读取。用户可在系统 SSH 工具解锁已有密钥。读取通过后仍要核对实际推送 URL、分支和写入结果。SSH 私钥留在本机。没有可用密钥时，按团队平台的 SSH 设置引导，或使用 HTTPS 继续。
- **已有 HTTPS 凭据**。先使用 `inspect`。公共仓库的匿名读取只说明可读。需要写入时，继续核对该分支的推送预检或按用户授权验证实际推送。
- **本机令牌或密码**。已有令牌或平台允许的账号密码时，直接运行 `login` 打开本机窗口，并在聊天中提供该窗口入口。用户在窗口内输入凭据。没有令牌时，可使用窗口提供的平台说明。
- **平台浏览器登录**。用户选择浏览器登录且本机已安装 Git Credential Manager 时，GitHub.com 与 GitLab.com 可运行 `browser-login`。用户在平台完成登录或同意授权后，脚本继续验证仓库访问。缺少组件时由 Agent 协助安装官方组件，或按用户选择使用本机输入窗口。自建实例按团队配置使用已有授权或本机输入方式。[Git Credential Manager](https://github.com/git-ecosystem/git-credential-manager) · [自建 GitLab 支持范围](https://github.com/git-ecosystem/git-credential-manager/blob/main/docs/gitlab.md)

## Agent 使用的脚本

`<skill-dir>` 是当前 SKILL.md 所在目录，命令由 Agent 运行，用户无需学习。

```bash
node <skill-dir>/scripts/git-access.mjs inspect --target <项目目录> --repository-url https://git.example.com/team/product.git
node <skill-dir>/scripts/git-access.mjs login --target <项目目录> --repository-url https://git.example.com/team/product.git
node <skill-dir>/scripts/git-access.mjs browser-login --target <项目目录> --repository-url https://gitlab.com/team/product.git
```

已有 HTTPS origin 可省略 --repository-url；自建 GitLab 可加 --provider gitlab。--no-open 用于无法自动打开浏览器时，返回同一台电脑上的窗口链接。窗口随机路径、仅监听 127.0.0.1，10 分钟过期，可点击取消；取消/超时等待进行中操作及必要回滚结束后退出；CLI 没有密码或令牌参数。脚本只做检测与凭据接入，不新建远端仓库、不改 origin、不提交、不实际推送、不部署。真正协作步骤由 Agent 接续执行。

inspect 的 ok 表示检测上下文可用，仍须检查 read、pushPreflight、identityConfigured 等结果。汇报 pushTarget 中的地址和分支。无提交、分离 HEAD、未配置上游、多个推送地址或推送 URL 与本次授权地址不同，均返回 not_checked 和原因。推送 URL 不同时单独核对并验证该目标的授权，不能用读取地址或本地分支名代替。预检使用 dry-run 且跳过本地 pre-push 钩子，以免授权过程触发项目代码。真实推送使用已核对的目标分支，正常执行钩子并核实远端 SHA。

## 登录方式与最小权限

| 平台 | 令牌 | 账号密码 |
| --- | --- | --- |
| GitHub | 首选仅选目标仓库的细粒度令牌，Contents 按任务授予读写；修改工作流还需对应权限 | Git HTTPS 不支持账号密码，窗口只允许令牌 |
| GitLab / 自建 GitLab | 按实例版本使用项目范围的细粒度权限，或传统 read_repository / write_repository | 仅实例允许且账号策略支持时使用；2FA 等策略可能要求令牌 |
| Gitee / 其他 HTTPS Git 服务 | 按服务策略使用已有令牌 | 按服务当前策略验证，不预设所有平台支持 |

GitHub 密码限制见 [官方认证说明](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/about-authentication-to-github)；细粒度令牌及工作流写权限见 [仓库内容 API 权限](https://docs.github.com/en/rest/repos/contents)。GitLab 见 [个人访问令牌](https://docs.gitlab.com/user/profile/personal_access_tokens/)、[传统权限范围](https://docs.gitlab.com/security/tokens/access_token_scopes/)、[细粒度 Git 权限](https://docs.gitlab.com/auth/tokens/fine_grained_access_tokens_other/) 和 [实例密码登录设置](https://docs.gitlab.com/administration/settings/sign_in_restrictions/)。按实际平台版本核实，不默认索取管理员、组织或所有仓库权限。

已有有效凭据可以直接登录，无需官方网页 OAuth。用户没有令牌、需要创建/续期令牌、SSO/验证码或管理员授予成员权限时，遵循平台要求；不要承诺跳过这些步骤，也不要代填验证挑战。

## 凭据保存与常见结果

密码/令牌只在本机隐藏输入，经回环 POST 进入本机进程；发送给用户明确选择的 HTTPS 仓库做验证。秘密不进入聊天、命令参数、仓库 URL、项目配置、.env、测试报告或日志。验证时通过短生命周期子进程环境和内存传递，不开启 HTTP 调试或追踪。不要让用户把秘密发给 Agent。

优先 macOS 钥匙串、Windows 凭据管理器、Linux 密钥环；缺少原生组件时可用 Git 内存 cache（最多 1 小时，过期后重新输入）。不用明文 credential.store。每个仓库单独配置 helper/useHttpPath/username，仅修改本项目配置，写入后回读验证；旧凭据读取超时、工具启动失败或取消时停止写入。保存失败恢复原凭据和项目配置，重复取消共用同一关闭过程并等待恢复结束，不报告成功。Git helper 静默失败与确实无旧值有时返回相同状态，单靠 Git fill 无法完全区分；存储异常时需核实系统组件，不宣称所有后端故障都能自动恢复。原生组件不可用时协助修复或采用内存缓存，不降级明文文件。参考 [Git 凭据机制](https://git-scm.com/docs/gitcredentials) 与 [credential 协议](https://git-scm.com/docs/git-credential)。

- repository_required / git_project_required：补齐准确仓库地址或建立目标目录本地仓库，再接续，不反复询问已知信息。
- parent_repository：脚本在联网或保存配置前返回所选目录与实际 Git 根目录。已确认沿用父仓库时，对该 Git 根目录执行授权，提交范围仍限于本次项目文件。选择独立仓库时，在其独立根目录接入。
- remote_mismatch / remote_needs_review：核对已有远端及连接方式。已可用 SSH 直接复用；要改为 HTTPS 时只处理用户已指定的同一仓库，保留其他配置，不猜测目标。
- unsafe_git_config / git_config_unavailable 表示仓库地址会被 Git 改写，或无法完整读取传输配置。先核对实际克隆地址和相关配置，再重新检测。
- access_failed：核对地址、网络、有效期和账号策略，不输出原始服务端错误或凭据。
- `browser_login_unsupported`、`credential_manager_required` 或 `browser_login_failed` 表示该地址、组件或会话无法完成浏览器登录。向用户提供本机令牌或密码入口，或按平台情况接续官方登录。
- write_access_failed：读取或写入通道未完整通过，不保存新凭据。检查令牌范围、仓库成员权限和服务兼容性；不能自行扩大账号权限。公共仓库读取成功可能仍是匿名读取，见 [GitLab 令牌排障](https://docs.gitlab.com/security/tokens/token_troubleshooting/)。
- credential_save_failed：安全组件或项目配置未保存，修复后重试，不当作已接入。
- pushPreflight failed：检查远端新提交、分支保护和团队分支规则，必要时按团队流程提交任务分支/PR，不绕过保护。服务发现及 dry-run 不证明真实更新已获准，最终以真实推送为准。
- Git 授权检测和预检使用隔离的传输配置，只访问核对过的 HTTPS 地址，强制校验证书并禁止重定向。支持复用 Git 的代理和可信 CA 设置。需要回退到 Node 写入服务发现时，按系统配置 Node 的代理和可信证书（例如 `NODE_EXTRA_CA_CERTS`）。实际 Git 推送前仍需核对实时配置和目标。
- 过期/撤销：本机窗口重新接入目标仓库。用户要求退出时仅移除该仓库、该账号对应的 helper 凭据和本项目 scoped 配置，保留其他仓库；清除本机缓存不代表远端令牌已吊销。

缺少真实仓库或凭据时，完成可做的本地交付，说明下一步缺少什么；不能报告已完成在线授权或推送。核验日期：2026-11-03。
